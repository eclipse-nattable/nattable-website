package com.beone.java.eclipsemagazinexamples.layer;

import java.util.List;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.IColumnPropertyAccessor;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.data.ReflectiveColumnPropertyAccessor;
import net.sourceforge.nattable.grid.layer.ColumnHeaderLayer;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;
import net.sourceforge.nattable.grid.layer.GridLayer;
import net.sourceforge.nattable.grid.layer.RowHeaderLayer;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.ILayer;
import net.sourceforge.nattable.layer.config.DefaultColumnHeaderLayerConfiguration;
import net.sourceforge.nattable.layer.config.DefaultRowHeaderLayerConfiguration;
import net.sourceforge.nattable.viewport.ViewportLayer;

import com.beone.java.eclipsemagazinexamples.configuration.CellLabelOverrider;
import com.beone.java.eclipsemagazinexamples.configuration.ColumnHeaderStyleConfiguration;
import com.beone.java.eclipsemagazinexamples.configuration.RowHeaderStyleConfiguration;
import com.beone.java.eclipsemagazinexamples.data.PersonWithAddress;

/**
 * Subclass of {@link CustomDataGridLayer} which overrides the creation of the row header, column header
 * and body layer stacks to adjust the styling.
 * @author Dirk H�u�ler
 */
public class StyledGridLayer extends CustomDataGridLayer {

	/**
	 * Creates at most a {@link DefaultGridLayer} expect that no {@link ReflectiveColumnPropertyAccessor}
	 * is used to access the data. Instead a customized {@link IColumnPropertyAccessor} is used.
	 * Also the styling of is adjusted here.
	 * @param values the list of the objects to show within the NatTable
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 */
	public StyledGridLayer(List<PersonWithAddress> values, ConfigRegistry configRegistry) {
		super(values, configRegistry);
	}
	
	/**
	 * Creates the layer stack for the body region of this {@link GridLayer}.
	 * This time we use a custom body layer stack as we want to customize one of the layers
	 * within the layer stack.
	 * Like the default implementation it shows the values of the objects accessed by the 
	 * {@link IDataProvider} and supports selection, reordering and hide/show of columns. 
	 * As the top layer of the body layer stack has to be a {@link ViewportLayer} it is scrollable, 
	 * resizable and is virtual.
	 * In this step we just want to customize the style configuration for the selection layer.
	 * @param bodyDataProvider The {@link IDataProvider} for the body.
	 * @return The layer stack for the body region of this {@link GridLayer}
	 */
	@Override
	protected ILayer createBodyLayerStack(ListDataProvider<PersonWithAddress> bodyDataProvider) {
		bodyDataLayer = new DataLayer(bodyDataProvider);
		
		bodyDataLayer.setConfigLabelAccumulator(new CellLabelOverrider(bodyDataProvider));
		
		StyledBodyLayerStack bodyLayer = new StyledBodyLayerStack(bodyDataLayer);
		selectionLayer = bodyLayer.getSelectionLayer();
		return bodyLayer;
	}
	
	/**
	 * {@inheritDoc}
	 * This specialization adds custom styling configuration to the column header.
	 */
	@Override
	protected ILayer createColumnHeaderLayer(
			IDataProvider columnHeaderDataProvider, 
			ILayer bodyLayer,
			ConfigRegistry configRegistry) {
		//create the data layer
		columnHeaderDataLayer = new DataLayer(columnHeaderDataProvider, 100, 20);
		//create a default column header layer for the given data layer and the dependency on the body layer
		//and don't use the default configuration
		ColumnHeaderLayer columnHeaderLayer = 
			new ColumnHeaderLayer(columnHeaderDataLayer, bodyLayer, selectionLayer, false);
		//add your special configuration for customizing
		columnHeaderLayer.addConfiguration(new DefaultColumnHeaderLayerConfiguration() {

			@Override
			protected void addColumnHeaderStyleConfig() {
				addConfiguration(new ColumnHeaderStyleConfiguration());
			}

		});
		return columnHeaderLayer;
	}
	
	/**
	 * {@inheritDoc}
	 * This specialization adds custom styling configuration to the row header.
	 */
	@Override
	protected ILayer createRowHeaderLayer(IDataProvider rowHeaderDataProvider, ILayer bodyLayer) {
		//create the data layer
		DataLayer rowHeaderDataLayer = new DataLayer(rowHeaderDataProvider, 20, 20);
		//create a default row header layer for the given data layer and the dependency on the body layer
		//and don't use the default configuration
		RowHeaderLayer rowHeaderLayer = 
			new RowHeaderLayer(rowHeaderDataLayer, bodyLayer, selectionLayer, false);
		//add your special configuration for customizing
		rowHeaderLayer.addConfiguration(new DefaultRowHeaderLayerConfiguration() {
			
			@Override
			protected void addRowHeaderStyleConfig() {
				addConfiguration(new RowHeaderStyleConfiguration());
			}
			
		});
		return rowHeaderLayer;
	}
}
