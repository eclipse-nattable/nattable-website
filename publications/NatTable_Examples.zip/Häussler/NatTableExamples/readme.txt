SimpleNatTableExample - simple example without any configurations
	- SimpleNatTableExample.java
	- data/Person.java
	
CustomDataNatTableExample - simple example using custom data access instead of reflection
	- CustomDataNatTableExample.java
	- layer/CustomDataGridLayer.java
	- data/DataModelConstants.java
	- data/PersonWithAddress.java
	- data/PersonWithAddressColumnPropertyAccessor.java
	
StyledNatTableExample - modifies the styling of the NatTable
	- StyledNatTableExample.java
	- layer/StyledGridLayer.java
	- layer/StyledBodyLayerStack.java
	- configuration/ColumnHeaderStyleConfiguration.java
	- configuration/RowHeaderStyleConfiguration.java
	- configuration/SelectionStyleConfiguration.java
	- configuration/CellLabelOverrider.java
	- configuration/TableStyleConfiguration.java
	- configuration/CustomHeaderMenuConfiguration.java
	
SortableNatTableExample - adds sorting to the NatTable with GlazedLists
	- SortableNatTableExample.java
	- layer/SortableGridLayer.java
	- configuration/CustomComparatorConfiguration.java
	
SimpleSortableNatTableExample - adds sorting to the NatTable with native list
	- SimpleSortableNatTableExample.java
	- layer/SimpleSortableGridLayer.java
	- data/PersonWithAddressSortModel.java
	
EditableNatTableExample - activates editing on NatTable
	- EditableNatTableExample.java
	- configuration/TableEditConfiguration.java
	- data/DateDisplayConverter.java

FilterableNatTableExample - adds the filter row to the NatTable
	- FilterableNatTableExample.java
	- layer/FilterableGridLayer.java
	- configuration/FilterRowCustomConfiguration.java