package com.beone.java.nattable.advanced.layer;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.IRowIdAccessor;
import net.sourceforge.nattable.selection.RowSelectionModel;
import net.sourceforge.nattable.selection.config.DefaultSelectionLayerConfiguration;

import com.beone.java.nattable.advanced.command.DeleteRowCommandHandler;
import com.beone.java.nattable.advanced.configuration.SelectionBindings;
import com.beone.java.nattable.advanced.configuration.SelectionStyleConfiguration;
import com.beone.java.nattable.data.PersonWithAddress;

/**
 * Subclass of {@link SortableGridLayer} which overrides the creation of the body layer stack 
 * to enable row selection and custom commands for select/deselect on mouse click and opening
 * popup menu with delete entry on right click to show the creation of custom commands.
 * 
 * @author Dirk Fauth
 */
public class CommandExampleGridLayer extends SortableGridLayer {

	/**
	 * @param values the list of the objects to show within the NatTable
	 * @param propertyNames String array with the property names of the model T
	 * @param propertyToLabelMap mapping from property name to column header label
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 */
	public CommandExampleGridLayer(
			List<PersonWithAddress> values, 
			String[] propertyNames,
			Map<String, String> propertyToLabelMap, 
			ConfigRegistry configRegistry) {
		super(values, propertyNames, propertyToLabelMap, configRegistry);
	}
	
	/**
	 * {@inheritDoc}
	 * Adding a new configuration with adjusted bindings to enable custom actions and
	 * commands. Also enabled row selection.
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected BodyLayerStack createBodyLayerStack(List<PersonWithAddress> values) {
		
		final BodyLayerStack bodyLayerStack = super.createBodyLayerStack(values);
		
		selectionLayer.clearConfiguration();
		selectionLayer.addConfiguration(new DefaultSelectionLayerConfiguration() {

			@Override
			protected void addSelectionStyleConfig() {
				addConfiguration(new SelectionStyleConfiguration());
			}
			
			@Override
			protected void addSelectionUIBindings() {
				addConfiguration(new SelectionBindings(bodyLayerStack.getViewportLayer()));
			}

		});
		
		selectionLayer.setSelectionModel(new RowSelectionModel<PersonWithAddress>(selectionLayer,
        	(IRowDataProvider<PersonWithAddress>) bodyDataLayer.getDataProvider(), 
        	new IRowIdAccessor<PersonWithAddress>() {
        		public Serializable getRowId(PersonWithAddress rowObject) {
        			//generate unique ID
        			return rowObject.getId();
        		}
        }));

		bodyLayerStack.registerCommandHandler(new DeleteRowCommandHandler(bodyDataLayer, sortedList));
		
		return bodyLayerStack;
	}
	
}
