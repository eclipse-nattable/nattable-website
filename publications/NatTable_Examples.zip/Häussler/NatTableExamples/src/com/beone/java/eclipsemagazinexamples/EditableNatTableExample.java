package com.beone.java.eclipsemagazinexamples;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.config.DefaultNatTableStyleConfiguration;
import net.sourceforge.nattable.data.ListDataProvider;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import ca.odell.glazedlists.GlazedLists;

import com.beone.java.eclipsemagazinexamples.configuration.CustomComparatorConfiguration;
import com.beone.java.eclipsemagazinexamples.configuration.CustomHeaderMenuConfiguration;
import com.beone.java.eclipsemagazinexamples.configuration.TableEditConfiguration;
import com.beone.java.eclipsemagazinexamples.configuration.TableStyleConfiguration;
import com.beone.java.eclipsemagazinexamples.data.PersonService;
import com.beone.java.eclipsemagazinexamples.data.PersonWithAddress;
import com.beone.java.eclipsemagazinexamples.data.PersonWithAddressColumnPropertyAccessor;
import com.beone.java.eclipsemagazinexamples.layer.CustomDataGridLayer;
import com.beone.java.eclipsemagazinexamples.layer.SortableGridLayer;

/**
 * Example that opens a window that shows a NatTable that contains several complex objects of
 * type {@link PersonWithAddress}.
 * It uses the customized {@link CustomDataGridLayer} for the {@link NatTable} which uses a customized
 * {@link PersonWithAddressColumnPropertyAccessor} to access the data within a {@link ListDataProvider} within
 * the body region. We also use a customized styling for column header, row header and selection and add
 * sorting by using the {@link GlazedLists}. 
 * 
 * In this example we enable the edit mode which is simply done by adding a configuration for the
 * edit behaviour.
 * 
 * @author Dirk H�u�ler
 */
public class EditableNatTableExample {

	/**
	 * Opens a new window and shows a grid build with {@link SortableNatTableExample#createControl(Composite)}
	 * @param args
	 */
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell(display, SWT.SHELL_TRIM);
		shell.setLayout(new FillLayout());
		shell.setSize(800, 600);
		shell.setText("Editable NatTable example");

		createControl(shell);
		
		shell.open();
		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}

		shell.dispose();
		display.dispose();
	}

	/**
	 * Creates a {@link NatTable} with {@link SortableGridLayer} that shows 
	 * {@link PersonWithAddress} objects with adjusted styling that are sortable.
	 * We also added conditional styling which is added within the body data provider
	 * and configured on the {@link NatTable} and we added header context menus to 
	 * enable functionalities. We also added custom comparators and enable the edit
	 * behaviour by configuration.
	 * @param parent
	 * @return
	 */
	public static Control createControl(Composite parent) {
		//create a new ConfigRegistry which will be needed for GlazedLists handling
		ConfigRegistry configRegistry = new ConfigRegistry();
		//create NatTable with autoconfigure off because we want to add our created configRegistry
		SortableGridLayer grid = 
			new SortableGridLayer(PersonService.getPersonsWithAddress(10), configRegistry);
		NatTable natTable = new NatTable(parent, 
				grid,
				false);
		//as the autoconfiguration of the NatTable is turned off, we have to add the 
		//DefaultNatTableStyleConfiguration and the ConfigRegistry manually	
		natTable.setConfigRegistry(configRegistry);
		natTable.addConfiguration(new DefaultNatTableStyleConfiguration());
		//add customized table style configuration
		natTable.addConfiguration(new TableStyleConfiguration());
		//add custom comparators for sorting
		natTable.addConfiguration(new CustomComparatorConfiguration(grid.getColumnHeaderDataLayer()));
		//add configuration for header context menus
		natTable.addConfiguration(new CustomHeaderMenuConfiguration(natTable));
		//add edit configuration
		natTable.addConfiguration(new TableEditConfiguration());
		
		natTable.configure();
		return natTable;
	}

}
