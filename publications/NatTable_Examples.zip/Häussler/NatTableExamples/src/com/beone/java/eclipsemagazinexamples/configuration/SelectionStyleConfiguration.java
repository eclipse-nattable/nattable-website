package com.beone.java.eclipsemagazinexamples.configuration;

import net.sourceforge.nattable.config.CellConfigAttributes;
import net.sourceforge.nattable.config.IConfigRegistry;
import net.sourceforge.nattable.grid.GridRegion;
import net.sourceforge.nattable.selection.config.DefaultSelectionStyleConfiguration;
import net.sourceforge.nattable.style.CellStyleAttributes;
import net.sourceforge.nattable.style.DisplayMode;
import net.sourceforge.nattable.style.Style;
import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;

/**
 * Custom style configuration for selections within a grid.
 * It overrides the {@link DefaultSelectionStyleConfiguration} by adjusting
 * the style properties on the one hand, and by decoupling the styling of the
 * column header and row header when selection occurs.
 * 
 * @author Dirk H�u�ler
 */
public class SelectionStyleConfiguration extends DefaultSelectionStyleConfiguration {

	{
		// Selection style
		this.selectionFont = GUIHelper.getFont(new FontData("Arial", 8, SWT.NORMAL));
		this.selectionBgColor = GUIHelper.COLOR_BLUE;
		this.selectionFgColor = GUIHelper.COLOR_WHITE;

		// Anchor style
		this.anchorBorderColor = GUIHelper.COLOR_DARK_GRAY;
		this.anchorBorderStyle = null;
		this.anchorBgColor = GUIHelper.COLOR_BLUE;
		this.anchorFgColor = GUIHelper.COLOR_WHITE;

		// Selected headers style
		this.selectedHeaderBgColor = GUIHelper.COLOR_GRAY;
		this.selectedHeaderFgColor = GUIHelper.COLOR_WHITE;
		this.selectedHeaderFont = GUIHelper.DEFAULT_FONT;
		this.selectedHeaderBorderStyle = null;
	}
	
	/**
	 * Font for showing selection within the row header.
	 * Needed because the default implementation thinks of showing the selection within the headers
	 * styled the same way.
	 */
	protected static final Font selectedRowHeaderFont = GUIHelper.getFont(new FontData("Arial", 8, SWT.ITALIC));

	/**
	 * Adds the style configuration for showing selections within the header regions of a grid.
	 * Unlike the default implementation we also split the style configuration for column and row
	 * header, as we want to show the selection within the row header in italics while in column header
	 * we want to use the default font.
	 */
	@Override
	protected void configureHeaderHasSelectionStyle(IConfigRegistry configRegistry) {
		Style cellStyle = new Style();
		cellStyle.setAttributeValue(CellStyleAttributes.FOREGROUND_COLOR, selectedHeaderFgColor);
		cellStyle.setAttributeValue(CellStyleAttributes.BACKGROUND_COLOR, selectedHeaderBgColor);
		cellStyle.setAttributeValue(CellStyleAttributes.FONT, selectedHeaderFont);
		cellStyle.setAttributeValue(CellStyleAttributes.BORDER_STYLE, selectedHeaderBorderStyle);

		configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_STYLE, cellStyle, DisplayMode.SELECT, GridRegion.COLUMN_HEADER);
		configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_STYLE, cellStyle, DisplayMode.SELECT, GridRegion.CORNER);
		
		//create new row header style with row header font italic
		Style rowHeaderCellStyle = new Style();
		rowHeaderCellStyle.setAttributeValue(CellStyleAttributes.FOREGROUND_COLOR, selectedHeaderFgColor);
		rowHeaderCellStyle.setAttributeValue(CellStyleAttributes.BACKGROUND_COLOR, selectedHeaderBgColor);
		rowHeaderCellStyle.setAttributeValue(CellStyleAttributes.FONT, selectedRowHeaderFont);
		rowHeaderCellStyle.setAttributeValue(CellStyleAttributes.BORDER_STYLE, selectedHeaderBorderStyle);
		configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_STYLE, rowHeaderCellStyle, DisplayMode.SELECT, GridRegion.ROW_HEADER);
	}
}
