package com.beone.java.eclipsemagazinexamples.layer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.IColumnPropertyAccessor;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.data.ReflectiveColumnPropertyAccessor;
import net.sourceforge.nattable.grid.data.DefaultColumnHeaderDataProvider;
import net.sourceforge.nattable.grid.data.DefaultCornerDataProvider;
import net.sourceforge.nattable.grid.data.DefaultRowHeaderDataProvider;
import net.sourceforge.nattable.grid.layer.ColumnHeaderLayer;
import net.sourceforge.nattable.grid.layer.CornerLayer;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;
import net.sourceforge.nattable.grid.layer.GridLayer;
import net.sourceforge.nattable.grid.layer.RowHeaderLayer;
import net.sourceforge.nattable.layer.AbstractLayer;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.ILayer;
import net.sourceforge.nattable.layer.stack.DefaultBodyLayerStack;
import net.sourceforge.nattable.selection.SelectionLayer;
import net.sourceforge.nattable.viewport.ViewportLayer;

import com.beone.java.eclipsemagazinexamples.data.PersonWithAddress;
import com.beone.java.eclipsemagazinexamples.data.PersonWithAddressColumnPropertyAccessor;

/**
 * Subclass of {@link GridLayer} which is functional almost the same as the {@link DefaultGridLayer}.
 * The only change here is that it uses a custom {@link IColumnPropertyAccessor} instead of the
 * {@link ReflectiveColumnPropertyAccessor}.
 * We also added methods to capsule layer creation so we can simply override those in further examples
 * without having to implement the same code over and over again.
 * @author Dirk H�u�ler
 */
public class CustomDataGridLayer extends GridLayer {

	/**
	 * The DataLayer of the body layer stack
	 */
	protected DataLayer bodyDataLayer;
	
	/**
	 * The DataLayer of the column header layer stack
	 */
	protected DataLayer columnHeaderDataLayer;
	
	/**
	 * The row header layer stack
	 */
	protected ILayer rowHeaderLayer;
	
	/**
	 * The column header layer stack
	 */
	protected ILayer columnHeaderLayer;

	/**
	 * The SelectionLayer of the body layer stack.
	 * Needed because the column and row header needs to react on selection within the body
	 * (showing the column and row selected if a cell is selected) and can be needed for additional
	 * functionality that depends on selection.
	 */
	protected SelectionLayer selectionLayer;
	
	/**
	 * The IColumnPropertyAccessor for accessing the object data.
	 * Needed as instance variable because of additional functionality in further examples.
	 */
	protected IColumnPropertyAccessor<PersonWithAddress> columnPropertyAccessor;

	/**
	 * Creates at most a {@link DefaultGridLayer} expect that no {@link ReflectiveColumnPropertyAccessor}
	 * is used to access the data. Instead a customized {@link IColumnPropertyAccessor} is used.
	 * @param values the list of the objects to show within the NatTable
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 */
	public CustomDataGridLayer(List<PersonWithAddress> values, ConfigRegistry configRegistry) {
		//use default configuration which adds default editing, excel export, print
		//and alternate row coloring configurations
		super(true);
		
		ListDataProvider<PersonWithAddress> bodyDataProvider = createBodyDataProvider(values);
		IDataProvider columnHeaderDataProvider = createColumnHeaderDataProvider();
		
		//create DefaultRowHeaderDataProvider which has one column that shows the row numbers
		IDataProvider rowHeaderDataProvider = 
			new DefaultRowHeaderDataProvider(bodyDataProvider);
		//create DefaultCornerDataProvider which simply returns nothing, which means the
		//corner is empty
		IDataProvider cornerDataProvider = 
			new DefaultCornerDataProvider(columnHeaderDataProvider, rowHeaderDataProvider);
		
		ILayer bodyLayer = createBodyLayerStack(bodyDataProvider);
		setBodyLayer(bodyLayer);
		
		columnHeaderLayer = createColumnHeaderLayer(
				columnHeaderDataProvider, 
				bodyLayer, 
				configRegistry);
		setColumnHeaderLayer(columnHeaderLayer);
		
		rowHeaderLayer = createRowHeaderLayer(
				rowHeaderDataProvider, 
				bodyLayer);
		setRowHeaderLayer(rowHeaderLayer);
		
		setCornerLayer(createCornerLayer(cornerDataProvider));
	}
	
	/**
	 * Creates the {@link IDataProvider} for the body region of this {@link GridLayer}.
	 * @param values the list of the objects to show within the NatTable
	 */
	protected ListDataProvider<PersonWithAddress> createBodyDataProvider(
			List<PersonWithAddress> values) {
		
		columnPropertyAccessor = new PersonWithAddressColumnPropertyAccessor();
		return new ListDataProvider<PersonWithAddress>(values, columnPropertyAccessor);
	}
	
	/**
	 * Creates the {@link IDataProvider} for the column header of this {@link GridLayer}.
	 * Should always return the same column count and values for all columns that
	 * are defined within the {@link IDataProvider} of the body layer stack.
	 * Uses the {@link DefaultColumnHeaderDataProvider} which simply checks for the property
	 * name within the propertyNames array and returns the corresponding value out
	 * of the propertyToLabelMap.
	 * Another approach is to implement a completely new {@link IDataProvider}
	 */
	protected IDataProvider createColumnHeaderDataProvider() {
		String[] propertyNames = {"firstName", "lastName", "gender", "married", "birthday", 
				"street", "housenumber", "postalcode", "city"};

		Map<String, String> propertyToLabelMap = new HashMap<String, String>();
		propertyToLabelMap.put("firstName", "Firstname");
		propertyToLabelMap.put("lastName", "Lastname");
		propertyToLabelMap.put("gender", "Gender");
		propertyToLabelMap.put("married", "Married");
		propertyToLabelMap.put("birthday", "Birthday");
		propertyToLabelMap.put("street", "Street");
		propertyToLabelMap.put("housenumber", "Housenumber");
		propertyToLabelMap.put("postalcode", "Postal Code");
		propertyToLabelMap.put("city", "City");

		return new DefaultColumnHeaderDataProvider(propertyNames, propertyToLabelMap);
	}
	
	/**
	 * Creates the layer stack for the body region of this {@link GridLayer}.
	 * The default implementation shows the values of the objects accessed by the {@link IDataProvider}
	 * and supports selection, reordering and hide/show of columns. As the top layer of the
	 * body layer stack has to be a {@link ViewportLayer} it is scrollable, resizable and is
	 * virtual.
	 * @param bodyDataProvider The {@link IDataProvider} for the body.
	 * @return The layer stack for the body region of this {@link GridLayer}
	 */
	protected ILayer createBodyLayerStack(ListDataProvider<PersonWithAddress> bodyDataProvider) {
		//create the DataLayer for the body region
		bodyDataLayer = new DataLayer(bodyDataProvider);
		//create a DefaultBodyLayerStack with the data layer as base layer
		DefaultBodyLayerStack bodyLayerStack = new DefaultBodyLayerStack(bodyDataLayer);
		selectionLayer = bodyLayerStack.getSelectionLayer();
		return bodyLayerStack;
	}
	
	/**
	 * Creates the layer stack for the column header region of this {@link GridLayer}.
	 * The default implementation shows the column names defined by the data provider and
	 * supports selection, resizing and reordering by drag and drop.  
	 * @param columnHeaderDataProvider The {@link IDataProvider} for the column header
	 * @param bodyLayer The body layer stack to which the column header should be dimensional dependent
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 * @return The layer stack for the column header region of this {@link GridLayer}
	 */
	protected ILayer createColumnHeaderLayer(
			IDataProvider columnHeaderDataProvider, 
			ILayer bodyLayer,
			ConfigRegistry configRegistry) {
		//create the DataLayer for the column header region with default width and height
		columnHeaderDataLayer = new DataLayer(columnHeaderDataProvider, 100, 20);
		//create a default ColumnHeaderLayer with the data layer as base layer, the dimensional
		//dependency on the body layer and the SelectionLayer for showing the selection of
		//a cell also within the column header
		ColumnHeaderLayer columnHeaderLayer = 
			new ColumnHeaderLayer(columnHeaderDataLayer, bodyLayer, selectionLayer);
		return columnHeaderLayer;
	}
	
	/**
	 * Creates the layer stack for the row header region of this {@link GridLayer}.
	 * The default implementation shows the values of the data provider and supports selection
	 * and resizing.
	 * @param rowHeaderDataProvider The {@link IDataProvider} for the row header
	 * @param bodyLayer The body layer stack to which the row header should be dimensional dependent
	 * @return The layer stack for the row header region of this {@link GridLayer}
	 */
	protected ILayer createRowHeaderLayer(
			IDataProvider rowHeaderDataProvider, 
			ILayer bodyLayer) {
		//create the DataLayer for the row header region with default width and height
		DataLayer rowHeaderDataLayer = new DataLayer(rowHeaderDataProvider, 20, 20);
		//create a default RowHeaderLayer with data layer as base layer, the dimensional 
		//dependency on the body layer and the SelectionLayer for showing the selection of
		//a cell also within the row header
		RowHeaderLayer rowHeaderLayer = 
			new RowHeaderLayer(rowHeaderDataLayer, bodyLayer, selectionLayer);
		return rowHeaderLayer;
	}
	
	/**
	 * Creates the layer stack for the corner region of this {@link GridLayer}.
	 * It only consists of a DataLayer that wraps an IDataProvider and is dimensionally
	 * dependent to the row header and the column header. 
	 * The corner of a grid does not support functionality by default.
	 * @param cornerDataProvider The {@link IDataProvider} for the corner layer.
	 * @return The layer stack for the corner region of this {@link GridLayer}.
	 */
	protected ILayer createCornerLayer(IDataProvider cornerDataProvider) {
		//create the DataLayer for the corner region with default width and height
		DataLayer cornerDataLayer = new DataLayer(cornerDataProvider, 20, 20);
		return new CornerLayer(cornerDataLayer, rowHeaderLayer, columnHeaderLayer);
	}

	/**
	 * @return The {@link DataLayer} for the body region of this {@link GridLayer}
	 */
	public AbstractLayer getBodyDataLayer() {
		return this.bodyDataLayer;
	}
	
	/**
	 * @return The {@link DataLayer} for the column header region of this {@link GridLayer}
	 */
	public AbstractLayer getColumnHeaderDataLayer() {
		return this.columnHeaderDataLayer;
	}
}
