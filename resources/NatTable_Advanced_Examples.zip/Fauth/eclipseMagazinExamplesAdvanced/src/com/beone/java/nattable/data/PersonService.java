package com.beone.java.nattable.data;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.beone.java.nattable.data.Person.Gender;

/**
 * Class that acts as service for accessing numerous {@link Person}s.
 * The values are randomly put together out of names and places from "The Simpsons"
 * 
 * @author Dirk Fauth
 */
public class PersonService {

	/**
	 * Creates a list of {@link Person}s. 
	 * @param numberOfPersons The number of {@link Person}s that should be generated.
	 * @return
	 */
	public static List<Person> getPersons(int numberOfPersons) {
		List<Person> result = new ArrayList<Person>();
		
		for (int i = 0; i < numberOfPersons; i++) {
			result.add(createPerson(i));
		}
		
		return result;
	}
	
	/**
	 * Creates a list of {@link PersonWithAddress}. 
	 * @param numberOfPersons The number of {@link PersonWithAddress} that should be generated.
	 * @return
	 */
	public static List<PersonWithAddress> getPersonsWithAddress(int numberOfPersons) {
		List<PersonWithAddress> result = new ArrayList<PersonWithAddress>();
		
		for (int i = 0; i < numberOfPersons; i++) {
			result.add(new PersonWithAddress(createPerson(i), createAddress()));
		}
		
		return result;
	}
	
	/**
	 * Creates a random person out of names which are taken from "The Simpsons" 
	 * and enrich them with random generated married state and birthday date.
	 * @return
	 */
	private static Person createPerson(int id) {
		String[] maleNames = {"Bart", "Homer", "Lenny", "Carl", "Waylon", "Ned", "Timothy"};
		String[] femaleNames = {"Marge", "Lisa", "Maggie", "Edna", "Helen", "Jessica"};
		String[] lastNames = {"Simpson", "Leonard", "Carlson", "Smithers", "Flanders", "Krabappel", "Lovejoy"};
		
		Random randomGenerator = new Random();
		
		Person result = new Person();
		result.setId(id);
		result.setGender(Gender.values()[randomGenerator.nextInt(2)]);
		
		if (result.getGender().equals(Gender.MALE)) {
			result.setFirstName(maleNames[randomGenerator.nextInt(maleNames.length)]);
		}
		else {
			result.setFirstName(femaleNames[randomGenerator.nextInt(femaleNames.length)]);
		}
		
		result.setLastName(lastNames[randomGenerator.nextInt(lastNames.length)]);
		result.setMarried(randomGenerator.nextBoolean());
		
		int month = randomGenerator.nextInt(12);
		int day = 0;
		if (month == 2) {
			day = randomGenerator.nextInt(28);
		}
		else {
			day = randomGenerator.nextInt(30);
		}
		int year = 1920 + randomGenerator.nextInt(90);
		
		SimpleDateFormat sdf = new SimpleDateFormat(DataModelConstants.DATE_FORMAT_PATTERN);
		try {
			result.setBirthday(sdf.parse(""+year+"-"+month+"-"+day));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	/**
	 * Creates a random address out of street names, postal codes and city names which are
	 * taken from "The Simpsons" 
	 * (i haven't found postal codes, so here i invented some for the example)
	 * @return
	 */
	private static Address createAddress() {
		String[] streets = {"Evergreen Terrace", "Main Street", "South Street", "Plympton Street", "Highland Avenue", "Elm Street", "Oak Grove Street"};
		int[] plz = {11111, 22222, 33333, 44444, 55555, 66666};
		String[] cities = {"Springfield", "Shelbyville", "Ogdenville", "Waverly Hills", "North Haverbrook", "Capital City"};
		
		Random randomGenerator = new Random();
		
		Address result = new Address();
		
		result.setStreet(streets[randomGenerator.nextInt(streets.length)]);
		result.setHousenumber(randomGenerator.nextInt(200));
		int cityRandom = randomGenerator.nextInt(cities.length);
		result.setPostalCode(plz[cityRandom]);
		result.setCity(cities[cityRandom]);
		
		return result;
	}
}
