package com.beone.java.nattable.advanced;

import java.util.HashMap;
import java.util.Map;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.config.DefaultNatTableStyleConfiguration;
import net.sourceforge.nattable.data.ExtendedReflectiveColumnPropertyAccessor;
import net.sourceforge.nattable.data.ListDataProvider;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.beone.java.nattable.advanced.configuration.CustomComparatorConfiguration;
import com.beone.java.nattable.advanced.configuration.CustomHeaderMenuConfiguration;
import com.beone.java.nattable.advanced.configuration.TableStyleConfiguration;
import com.beone.java.nattable.advanced.layer.ColumnGroupingGridLayer;
import com.beone.java.nattable.data.PersonService;
import com.beone.java.nattable.data.PersonWithAddress;

/**
 * Example that opens a window that shows a NatTable that contains several complex objects of
 * type {@link PersonWithAddress}.
 * It uses the customized {@link ColumnGroupingGridLayer} for the {@link NatTable} which uses the
 * {@link ExtendedReflectiveColumnPropertyAccessor} to access the data within a {@link ListDataProvider} of
 * the body region. We also use a customized styling for column header, row header and selection. 
 * 
 * In this example we also add the column grouping functionality .
 * 
 * @author Dirk Fauth
 * 
 */
public class ColumnGroupingNatTableExample {

	/**
	 * Opens a new window and shows a grid build with {@link ColumnGroupingNatTableExample#createControl(Composite)}
	 * @param args
	 */
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell(display, SWT.SHELL_TRIM);
		shell.setLayout(new FillLayout());
		shell.setSize(800, 600);
		shell.setText("NatTable example for column grouping");

		createControl(shell);
		
		shell.open();
		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}

		shell.dispose();
		display.dispose();
	}

	/**
	 * Creates a {@link NatTable} with {@link ColumnGroupingGridLayer} that shows 
	 * {@link PersonWithAddress} objects with adjusted styling while the columns
	 * are grouped for person and address information.
	 * @param parent
	 * @return
	 */
	public static Control createControl(Composite parent) {
		//create a new ConfigRegistry which will be needed for GlazedLists handling
		ConfigRegistry configRegistry = new ConfigRegistry();
		
		String[] propertyNames = {"lastName", "firstName", "gender", "married", "birthday", 
				"address.street", "address.housenumber", "address.postalCode", "address.city"};

		Map<String, String> propertyToLabelMap = new HashMap<String, String>();
		propertyToLabelMap.put("firstName", "Firstname");
		propertyToLabelMap.put("lastName", "Lastname");
		propertyToLabelMap.put("gender", "Gender");
		propertyToLabelMap.put("married", "Married");
		propertyToLabelMap.put("birthday", "Birthday");
		propertyToLabelMap.put("address.street", "Street");
		propertyToLabelMap.put("address.housenumber", "Housenumber");
		propertyToLabelMap.put("address.postalCode", "Postal Code");
		propertyToLabelMap.put("address.city", "City");

		//create NatTable with autoconfigure off because we want to add our created configRegistry
		ColumnGroupingGridLayer grid = 
			new ColumnGroupingGridLayer(PersonService.getPersonsWithAddress(10), 
					propertyNames, propertyToLabelMap, configRegistry);
		
		grid.getColumnGroupHeaderLayer().addColumnsIndexesToGroup("Personendaten", 0, 1, 2, 3, 4);
		grid.getColumnGroupHeaderLayer().addColumnsIndexesToGroup("Adressdaten", 5, 6, 7, 8);
		
		NatTable natTable = new NatTable(parent, 
				grid,
				false);
		//as the autoconfiguration of the NatTable is turned off, we have to add the 
		//DefaultNatTableStyleConfiguration and the ConfigRegistry manually	
		natTable.setConfigRegistry(configRegistry);
		natTable.addConfiguration(new DefaultNatTableStyleConfiguration());
		//add customized table style configuration
		natTable.addConfiguration(new TableStyleConfiguration());
		//add custom comparators for sorting
		natTable.addConfiguration(new CustomComparatorConfiguration(grid.getColumnHeaderDataLayer()));
		//add configuration for header context menus
		natTable.addConfiguration(new CustomHeaderMenuConfiguration(natTable));
		natTable.configure();
		return natTable;
	}

}
