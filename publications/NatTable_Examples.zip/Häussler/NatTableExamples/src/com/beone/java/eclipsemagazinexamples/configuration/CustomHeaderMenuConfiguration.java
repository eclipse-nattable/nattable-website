package com.beone.java.eclipsemagazinexamples.configuration;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.ui.menu.HeaderMenuConfiguration;
import net.sourceforge.nattable.ui.menu.PopupMenuBuilder;

/**
 * Overrides the {@link HeaderMenuConfiguration} to only enable the user
 * to hide and show, auto resize and rename columns via context menu.
 * @author Dirk H�u�ler
 */
public class CustomHeaderMenuConfiguration extends HeaderMenuConfiguration {

	public CustomHeaderMenuConfiguration(NatTable natTable) {
		super(natTable);
	}
	
	@Override
	protected PopupMenuBuilder createColumnHeaderMenu(NatTable natTable) {
		return new PopupMenuBuilder(natTable)
								.withHideColumnMenuItem()
								.withShowAllColumnsMenuItem()
								.withAutoResizeSelectedColumnsMenuItem()
								.withColumnRenameDialog();
	}
}
