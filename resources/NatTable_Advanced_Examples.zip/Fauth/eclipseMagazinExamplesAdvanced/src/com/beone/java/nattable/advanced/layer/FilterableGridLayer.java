package com.beone.java.nattable.advanced.layer;

import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsEventLayer;
import net.sourceforge.nattable.extension.glazedlists.filterrow.DefaultGlazedListsFilterStrategy;
import net.sourceforge.nattable.filterrow.FilterRowHeaderComposite;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;
import net.sourceforge.nattable.grid.layer.GridLayer;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.ILayer;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.FilterList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.SortedList;
import ca.odell.glazedlists.TransformedList;
import ca.odell.glazedlists.matchers.CompositeMatcherEditor;

import com.beone.java.nattable.advanced.configuration.CellLabelOverrider;
import com.beone.java.nattable.data.PersonWithAddress;

/**
 * Subclass of {@link SortableGridLayer} which overrides the creation of the column header
 * and body layer stacks and the body data provider to enable filtering with GlazedLists by
 * adding a filter row to the column header.
 * 
 * @author Dirk Fauth
 */
public class FilterableGridLayer extends SortableGridLayer {

	/**
	 * Reference to the GlazedLists which wraps the original data list.
	 */
	protected FilterList<PersonWithAddress> filterList;
	
	/**
	 * Creates a {@link GridLayer} that has all functionality a {@link DefaultGridLayer} has,
	 * adding custom data access, styling, sorting and filtering to the NatTable.
	 * @param values the list of the objects to show within the NatTable
	 * @param propertyNames String array with the property names of the model T
	 * @param propertyToLabelMap mapping from property name to column header label
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 */
	public FilterableGridLayer(
			List<PersonWithAddress> values, 
			String[] propertyNames,
			Map<String, String> propertyToLabelMap, 
			ConfigRegistry configRegistry) {
		super(values, propertyNames, propertyToLabelMap, configRegistry);
	}
	
	/**
	 * {@inheritDoc}
	 * The only change to {@link SortableGridLayer#createBodyLayerStack(ListDataProvider)} is that
	 * the {@link GlazedListsEventLayer} ist created with the filterList and not the sortedList.
	 */
	@Override
	protected BodyLayerStack createBodyLayerStack(List<PersonWithAddress> values) {
		//wrapping of the list to show into GlazedLists
		//see http://publicobject.com/glazedlists/ for further information
		EventList<PersonWithAddress> eventList = GlazedLists.eventList(values);
		TransformedList<PersonWithAddress, PersonWithAddress> rowObjectsGlazedList = GlazedLists.threadSafeList(eventList);
		
		//use the SortedList constructor with 'null' for the Comparator because the Comparator
		//will be set by configuration
		sortedList = new SortedList<PersonWithAddress>(rowObjectsGlazedList, null);
		// wrap the SortedList with the FilterList
		filterList = new FilterList<PersonWithAddress>(sortedList);
		
		IDataProvider bodyDataProvider = 
			new ListDataProvider<PersonWithAddress>(filterList, columnPropertyAccessor);
		bodyDataLayer = new DataLayer(bodyDataProvider);
		bodyDataLayer.setConfigLabelAccumulator(new CellLabelOverrider(bodyDataProvider));
		
		//layer for event handling of GlazedLists and PropertyChanges
		GlazedListsEventLayer<PersonWithAddress> glazedListsEventLayer = 
			new GlazedListsEventLayer<PersonWithAddress>(bodyDataLayer, filterList);

		BodyLayerStack bodyLayerStack = new BodyLayerStack(glazedListsEventLayer);
		selectionLayer = bodyLayerStack.getSelectionLayer();
		return bodyLayerStack;
	}
	
	/**
	 * {@inheritDoc}
	 * It also adds the {@link FilterRowHeaderComposite} to enable the filter row.
	 */
	@Override
	protected ILayer createColumnHeaderLayer(
			BodyLayerStack bodyLayer,
			ConfigRegistry configRegistry) {
		
		ILayer columnHeaderLayer = super.createColumnHeaderLayer(
				bodyLayer, configRegistry);
		
		//	Note: The column header layer is wrapped in a filter row composite.
		//	This plugs in the filter row functionality
		CompositeMatcherEditor<PersonWithAddress> autoFilterMatcherEditor = new CompositeMatcherEditor<PersonWithAddress>();
		filterList.setMatcherEditor(autoFilterMatcherEditor);
		
		FilterRowHeaderComposite<PersonWithAddress> filterRowHeaderLayer =
			new FilterRowHeaderComposite<PersonWithAddress>(
					new DefaultGlazedListsFilterStrategy<PersonWithAddress>(autoFilterMatcherEditor, columnPropertyAccessor, configRegistry),
					columnHeaderLayer, columnHeaderDataLayer.getDataProvider(), configRegistry
			);
		
		return filterRowHeaderLayer;
	}
}
