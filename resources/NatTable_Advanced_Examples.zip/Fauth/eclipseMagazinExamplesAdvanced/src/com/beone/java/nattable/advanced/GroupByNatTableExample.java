package com.beone.java.nattable.advanced;

import java.util.HashMap;
import java.util.Map;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.config.DefaultNatTableStyleConfiguration;
import net.sourceforge.nattable.data.ExtendedReflectiveColumnPropertyAccessor;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.extension.glazedlists.groupBy.GroupByHeaderLayer;
import net.sourceforge.nattable.extension.glazedlists.groupBy.GroupByHeaderMenuConfiguration;
import net.sourceforge.nattable.layer.CompositeLayer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import ca.odell.glazedlists.GlazedLists;

import com.beone.java.nattable.advanced.configuration.CustomComparatorConfiguration;
import com.beone.java.nattable.advanced.configuration.CustomHeaderMenuConfiguration;
import com.beone.java.nattable.advanced.configuration.TableStyleConfiguration;
import com.beone.java.nattable.advanced.layer.GroupByGridLayer;
import com.beone.java.nattable.data.PersonService;
import com.beone.java.nattable.data.PersonWithAddress;

/**
 * Example that opens a window that shows a NatTable that contains several
 * complex objects of type {@link PersonWithAddress}. It uses the customized
 * {@link GroupByGridLayer} for the {@link NatTable} which uses the
 * {@link ExtendedReflectiveColumnPropertyAccessor} to access the data within a
 * {@link ListDataProvider} of the body region. We also use a customized styling
 * for column header, row header and selection.
 * 
 * In this example we add the group by functionality by using
 * {@link GlazedLists} and the extensions for {@link GlazedLists} of the
 * NatTable project.
 * 
 * @author Dirk Fauth
 * 
 */
public class GroupByNatTableExample {

	/**
	 * Opens a new window and shows a grid build with
	 * {@link GroupByNatTableExample#createControl(Composite)}
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell(display, SWT.SHELL_TRIM);
		shell.setLayout(new FillLayout());
		shell.setSize(800, 600);
		shell.setText("NatTable example for group by feature");

		createControl(shell);

		shell.open();

		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}

		shell.dispose();
		display.dispose();
	}

	/**
	 * Creates a {@link NatTable} with {@link GroupByGridLayer} that shows
	 * {@link PersonWithAddress} objects with adjusted styling that can be
	 * grouped.
	 * 
	 * @param parent
	 * @return
	 */
	public static Control createControl(Composite parent) {
		// create a new ConfigRegistry which will be needed for GlazedLists
		// handling
		ConfigRegistry configRegistry = new ConfigRegistry();

		String[] propertyNames = { "lastName", "firstName", "gender",
				"married", "birthday", "address.street", "address.housenumber",
				"address.postalCode", "address.city" };

		Map<String, String> propertyToLabelMap = new HashMap<String, String>();
		propertyToLabelMap.put("firstName", "Firstname");
		propertyToLabelMap.put("lastName", "Lastname");
		propertyToLabelMap.put("gender", "Gender");
		propertyToLabelMap.put("married", "Married");
		propertyToLabelMap.put("birthday", "Birthday");
		propertyToLabelMap.put("address.street", "Street");
		propertyToLabelMap.put("address.housenumber", "Housenumber");
		propertyToLabelMap.put("address.postalCode", "Postal Code");
		propertyToLabelMap.put("address.city", "City");

		// create NatTable with autoconfigure off because we want to add our
		// created configRegistry
		GroupByGridLayer grid = new GroupByGridLayer(
				PersonService.getPersonsWithAddress(100), propertyNames,
				propertyToLabelMap, configRegistry);

		CompositeLayer compositeGridLayer = new CompositeLayer(1, 2);
		GroupByHeaderLayer groupByHeaderLayer = new GroupByHeaderLayer(
				grid.getGroupByModel(), grid, grid.getColumnHeaderDataLayer()
						.getDataProvider());
		compositeGridLayer.setChildLayer(GroupByHeaderLayer.GROUP_BY_REGION,
				groupByHeaderLayer, 0, 0);
		compositeGridLayer.setChildLayer("Grid", grid, 0, 1);

		NatTable natTable = new NatTable(parent, compositeGridLayer, false);
		// as the autoconfiguration of the NatTable is turned off, we have to
		// add the
		// DefaultNatTableStyleConfiguration and the ConfigRegistry manually
		natTable.setConfigRegistry(configRegistry);
		natTable.addConfiguration(new DefaultNatTableStyleConfiguration());
		// add customized table style configuration
		natTable.addConfiguration(new TableStyleConfiguration());
		// add custom comparators for sorting
		natTable.addConfiguration(new CustomComparatorConfiguration(grid
				.getColumnHeaderDataLayer()));
		// add configuration for header context menus
		natTable.addConfiguration(new CustomHeaderMenuConfiguration(natTable));
		// add group by configuration
		natTable.addConfiguration(new GroupByHeaderMenuConfiguration(natTable,
				groupByHeaderLayer));
		natTable.configure();
		return natTable;
	}

}
