package com.beone.java.eclipsemagazinexamples.configuration;

import net.sourceforge.nattable.config.AbstractRegistryConfiguration;
import net.sourceforge.nattable.config.CellConfigAttributes;
import net.sourceforge.nattable.config.IConfigRegistry;
import net.sourceforge.nattable.painter.cell.CheckBoxPainter;
import net.sourceforge.nattable.style.CellStyleAttributes;
import net.sourceforge.nattable.style.DisplayMode;
import net.sourceforge.nattable.style.Style;
import net.sourceforge.nattable.util.GUIHelper;

import com.beone.java.eclipsemagazinexamples.data.Person;

/**
 * Style configurations for conditional styling.
 * Adds a yellow background style to cells that show a {@link Person.Gender#FEMALE}
 * and sets a {@link CheckBoxPainter} to cells that show the married information of
 * a {@link Person}.
 * 
 * @author Dirk H�u�ler
 */
public class TableStyleConfiguration extends AbstractRegistryConfiguration {

	@Override
	public void configureRegistry(IConfigRegistry configRegistry) {
		//register a style with yellow background for female entries
		Style femaleStyle = new Style();
		femaleStyle.setAttributeValue(
				CellStyleAttributes.BACKGROUND_COLOR, GUIHelper.COLOR_YELLOW);
		
		configRegistry.registerConfigAttribute(
				CellConfigAttributes.CELL_STYLE, 
				femaleStyle,
				DisplayMode.NORMAL,
				CellLabelOverrider.FEMALE_LABEL);
		
		//register a CheckBoxPainter as CellPainter for the married information
		configRegistry.registerConfigAttribute(
				CellConfigAttributes.CELL_PAINTER, 
				new CheckBoxPainter(), 
				DisplayMode.NORMAL, 
				CellLabelOverrider.MARRIED_LABEL);

	}

}
