package com.beone.java.nattable.advanced.layer;

import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsEventLayer;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsSortModel;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;
import net.sourceforge.nattable.grid.layer.GridLayer;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.ILayer;
import net.sourceforge.nattable.sort.ISortModel;
import net.sourceforge.nattable.sort.SortHeaderLayer;
import net.sourceforge.nattable.sort.config.SingleClickSortConfiguration;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.SortedList;
import ca.odell.glazedlists.TransformedList;

import com.beone.java.nattable.advanced.configuration.CellLabelOverrider;
import com.beone.java.nattable.data.PersonWithAddress;

/**
 * Subclass of {@link BaseGridLayer} which overrides the creation of the column header
 * and body layer stacks and the body data provider to enable sorting with GlazedLists.
 * 
 * @author Dirk Fauth
 */
public class SortableGridLayer extends BaseGridLayer {

	protected ISortModel sortModel;
	
	/**
	 * Reference to the sorted list which wraps the original data list.
	 */
	protected SortedList<PersonWithAddress> sortedList;
	
	/**
	 * Creates a {@link GridLayer} that has all functionality a {@link DefaultGridLayer} has,
	 * adding custom data access, styling and sorting to the NatTable.
	 * @param values the list of the objects to show within the NatTable
	 * @param propertyNames String array with the property names of the model T
	 * @param propertyToLabelMap mapping from property name to column header label
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 */
	public SortableGridLayer(
			List<PersonWithAddress> values, 
			String[] propertyNames,
			Map<String, String> propertyToLabelMap, 
			ConfigRegistry configRegistry) {
		super(values, propertyNames, propertyToLabelMap, configRegistry);
	}
	
	/**
	 * {@inheritDoc}
	 * To handle events fired by {@link GlazedLists} automatically, we add the {@link GlazedListsEventLayer}
	 * on top of the {@link DataLayer} before we add other functional layer. This way we don't have to
	 * handle those events manually to update the view on structural data changes.
	 */
	@Override
	protected BodyLayerStack createBodyLayerStack(List<PersonWithAddress> values) {
		//wrapping of the data list into GlazedLists
		//see http://publicobject.com/glazedlists/ for further information
		EventList<PersonWithAddress> eventList = GlazedLists.eventList(values);
		TransformedList<PersonWithAddress, PersonWithAddress> rowObjectsGlazedList = GlazedLists.threadSafeList(eventList);
		
		//use the SortedList constructor with 'null' for the Comparator because the Comparator
		//will be set by configuration
		sortedList = new SortedList<PersonWithAddress>(rowObjectsGlazedList, null);
		
		IDataProvider bodyDataProvider = 
			new ListDataProvider<PersonWithAddress>(sortedList, columnPropertyAccessor);
		bodyDataLayer = new DataLayer(bodyDataProvider);
		bodyDataLayer.setConfigLabelAccumulator(new CellLabelOverrider(bodyDataProvider));
		
		//layer for event handling of GlazedLists and PropertyChanges
		GlazedListsEventLayer<PersonWithAddress> glazedListsEventLayer = 
			new GlazedListsEventLayer<PersonWithAddress>(bodyDataLayer, sortedList);
		
		BodyLayerStack bodyLayerStack = new BodyLayerStack(glazedListsEventLayer);
		selectionLayer = bodyLayerStack.getSelectionLayer();
		return bodyLayerStack;
	}
	
	/**
	 * {@inheritDoc}
	 * It also adds the {@link SortHeaderLayer} to enable sorting.
	 */
	@Override
	protected ILayer createColumnHeaderLayer(
			BodyLayerStack bodyLayer,
			ConfigRegistry configRegistry) {
		
		ILayer columnHeaderLayer = super.createColumnHeaderLayer(
				bodyLayer, configRegistry);
		
		//add the SortHeaderLayer to the column header layer stack
		//as we use GlazedLists, we use the GlazedListsSortModel which delegates
		//the sorting to the SortedList
		sortModel = new GlazedListsSortModel<PersonWithAddress>(
				sortedList, 
				columnPropertyAccessor,
				configRegistry, 
				columnHeaderDataLayer);
				
		SortHeaderLayer<PersonWithAddress> sortHeaderLayer = new SortHeaderLayer<PersonWithAddress>(
				columnHeaderLayer, sortModel, false);
		//override the default sort configuration and change the mouse bindings to sort on a single click
		sortHeaderLayer.addConfiguration(new SingleClickSortConfiguration());

		return sortHeaderLayer;
	}
	
}
