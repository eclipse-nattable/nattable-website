package com.beone.java.eclipsemagazinexamples.layer;

import java.util.List;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsEventLayer;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsSortModel;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;
import net.sourceforge.nattable.grid.layer.GridLayer;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.ILayer;
import net.sourceforge.nattable.sort.SortHeaderLayer;
import net.sourceforge.nattable.sort.config.SingleClickSortConfiguration;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.SortedList;
import ca.odell.glazedlists.TransformedList;

import com.beone.java.eclipsemagazinexamples.configuration.CellLabelOverrider;
import com.beone.java.eclipsemagazinexamples.data.PersonWithAddress;
import com.beone.java.eclipsemagazinexamples.data.PersonWithAddressColumnPropertyAccessor;

/**
 * Subclass of {@link StyledGridLayer} which overrides the creation of the column header
 * and body layer stacks and the body data provider to enable sorting with GlazedLists.
 * @author Dirk H�u�ler
 */
public class SortableGridLayer extends StyledGridLayer {

	/**
	 * Reference to the sorted list which wraps the original data list.
	 */
	protected SortedList<PersonWithAddress> sortedList;
	
	/**
	 * Creates a {@link GridLayer} that has all functionality a {@link DefaultGridLayer} has,
	 * adding custom data access, styling and sorting to the NatTable.
	 * @param values the list of the objects to show within the NatTable
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 */
	public SortableGridLayer(List<PersonWithAddress> values, ConfigRegistry configRegistry) {
		super(values, configRegistry);
	}
	
	/**
	 * {@inheritDoc}
	 * The data list is wrapped by GlazedLists before the {@link ListDataProvider} is created.
	 */
	@Override
	protected ListDataProvider<PersonWithAddress> createBodyDataProvider(List<PersonWithAddress> values) {
		//wrapping of the data list into GlazedLists
		//see http://publicobject.com/glazedlists/ for further information
		EventList<PersonWithAddress> eventList = GlazedLists.eventList(values);
		TransformedList<PersonWithAddress, PersonWithAddress> rowObjectsGlazedList = GlazedLists.threadSafeList(eventList);
		
		//use the SortedList constructor with 'null' for the Comparator because the Comparator
		//will be set by configuration
		sortedList = new SortedList<PersonWithAddress>(rowObjectsGlazedList, null);
		columnPropertyAccessor = new PersonWithAddressColumnPropertyAccessor();
		return new ListDataProvider<PersonWithAddress>(sortedList, columnPropertyAccessor);
	}
	
	/**
	 * {@inheritDoc}
	 * To handle events fired by {@link GlazedLists} automatically, we add the {@link GlazedListsEventLayer}
	 * on top of the {@link DataLayer} before we add other functional layer. This way we don't have to
	 * handle those events manually to update the view on structural data changes.
	 */
	@Override
	protected ILayer createBodyLayerStack(ListDataProvider<PersonWithAddress> bodyDataProvider) {
		bodyDataLayer = new DataLayer(bodyDataProvider);
		bodyDataLayer.setConfigLabelAccumulator(new CellLabelOverrider(bodyDataProvider));
		
		//layer for event handling of GlazedLists and PropertyChanges
		GlazedListsEventLayer<PersonWithAddress> glazedListsEventLayer = 
			new GlazedListsEventLayer<PersonWithAddress>(bodyDataLayer, sortedList);
		
		StyledBodyLayerStack bodyLayerStack = new StyledBodyLayerStack(glazedListsEventLayer);
		selectionLayer = bodyLayerStack.getSelectionLayer();
		return bodyLayerStack;
	}
	
	/**
	 * {@inheritDoc}
	 * It also adds the {@link SortHeaderLayer} to enable sorting.
	 */
	@Override
	protected ILayer createColumnHeaderLayer(
			IDataProvider columnHeaderDataProvider, 
			ILayer bodyLayer,
			ConfigRegistry configRegistry) {
		
		ILayer columnHeaderLayer = super.createColumnHeaderLayer(
				columnHeaderDataProvider, bodyLayer, configRegistry);
		
		//add the SortHeaderLayer to the column header layer stack
		//as we use GlazedLists, we use the GlazedListsSortModel which delegates
		//the sorting to the SortedList
		SortHeaderLayer<PersonWithAddress> sortHeaderLayer = new SortHeaderLayer<PersonWithAddress>(
				columnHeaderLayer, 
				new GlazedListsSortModel<PersonWithAddress>(
						sortedList, 
						columnPropertyAccessor,
						configRegistry, 
						columnHeaderDataLayer),
						false);
		//override the default sort configuration and change the mouse bindings to sort on a single click
		sortHeaderLayer.addConfiguration(new SingleClickSortConfiguration());

		return sortHeaderLayer;
	}
}
