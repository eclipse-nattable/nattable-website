package com.beone.java.nattable.advanced.command;

import net.sourceforge.nattable.command.AbstractContextFreeCommand;

/**
 * Command for deleting rows. Will carry an array of row indexes to delete.
 * 
 * @author Dirk Fauth
 *
 */
public class DeleteRowCommand extends AbstractContextFreeCommand {

	private int[] rowIndexes;
	
	public DeleteRowCommand(int[] rowIndexes) {
		this.rowIndexes = rowIndexes;
	}

	public int[] getRowIndexes() {
		return rowIndexes;
	}

}
