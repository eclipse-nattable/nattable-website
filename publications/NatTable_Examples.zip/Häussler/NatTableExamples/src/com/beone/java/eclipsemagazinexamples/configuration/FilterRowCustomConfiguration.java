package com.beone.java.eclipsemagazinexamples.configuration;

import java.util.Arrays;
import java.util.Comparator;

import net.sourceforge.nattable.config.AbstractRegistryConfiguration;
import net.sourceforge.nattable.config.IConfigRegistry;
import net.sourceforge.nattable.edit.EditConfigAttributes;
import net.sourceforge.nattable.edit.editor.ComboBoxCellEditor;
import net.sourceforge.nattable.filterrow.FilterRowDataLayer;
import net.sourceforge.nattable.filterrow.TextMatchingMode;
import net.sourceforge.nattable.filterrow.config.FilterRowConfigAttributes;
import net.sourceforge.nattable.style.DisplayMode;

import com.beone.java.eclipsemagazinexamples.data.DataModelConstants;
import com.beone.java.eclipsemagazinexamples.data.Person.Gender;

public class FilterRowCustomConfiguration extends AbstractRegistryConfiguration {

	@Override
	public void configureRegistry(IConfigRegistry configRegistry) {
		// Configure custom comparator on the firstname column
		configRegistry.registerConfigAttribute(FilterRowConfigAttributes.FILTER_COMPARATOR,
				getIngnorecaseComparator(),
				DisplayMode.NORMAL,
				FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + DataModelConstants.FIRSTNAME_COLUMN_POSITION);

		// Configure custom comparator on the lastname column
		configRegistry.registerConfigAttribute(FilterRowConfigAttributes.FILTER_COMPARATOR,
				getIngnorecaseComparator(),
				DisplayMode.NORMAL,
				FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + DataModelConstants.LASTNAME_COLUMN_POSITION);

		// Register a combo box editor for Gender to be displayed in the filter row cell 
		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITOR, 
				new ComboBoxCellEditor(Arrays.asList(Gender.FEMALE, Gender.MALE)), 
				DisplayMode.NORMAL, 
				FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + DataModelConstants.GENDER_COLUMN_POSITION);

		// Register the text matching mode to be exact for the gender (otherwise you would see FEMALE and MALE
		// on filtering for MALE)
		configRegistry.registerConfigAttribute(FilterRowConfigAttributes.TEXT_MATCHING_MODE,
				TextMatchingMode.EXACT,
				DisplayMode.NORMAL,
				FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + DataModelConstants.GENDER_COLUMN_POSITION);

		// Register a combo box editor for married to be displayed in the filter row cell 
		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITOR, 
				new ComboBoxCellEditor(Arrays.asList(Boolean.TRUE, Boolean.FALSE)), 
				DisplayMode.NORMAL, 
				FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + DataModelConstants.MARRIED_COLUMN_POSITION);

	}
	
	private static Comparator<?> getIngnorecaseComparator() {
		return new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareToIgnoreCase(o2);
			}
		};
	};

}
