package com.beone.java.eclipsemagazinexamples.layer;

import java.util.List;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;
import net.sourceforge.nattable.grid.layer.GridLayer;
import net.sourceforge.nattable.layer.ILayer;
import net.sourceforge.nattable.sort.SortHeaderLayer;
import net.sourceforge.nattable.sort.config.SingleClickSortConfiguration;

import com.beone.java.eclipsemagazinexamples.data.PersonWithAddress;
import com.beone.java.eclipsemagazinexamples.data.PersonWithAddressSortModel;

/**
 * Subclass of {@link StyledGridLayer} which overrides the creation of the column header
 * and body layer stacks and the body data provider to enable sorting.
 * @author Dirk H�u�ler
 */
public class SimpleSortableGridLayer extends StyledGridLayer {

	/**
	 * Creates a {@link GridLayer} that has all functionality a {@link DefaultGridLayer} has,
	 * adding custom data access, styling and sorting to the NatTable.
	 * @param values the list of the objects to show within the NatTable
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 */
	public SimpleSortableGridLayer(List<PersonWithAddress> values, ConfigRegistry configRegistry) {
		super(values, configRegistry);
	}
	
	/**
	 * {@inheritDoc}
	 * It also adds the {@link SortHeaderLayer} to enable sorting.
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected ILayer createColumnHeaderLayer(
			IDataProvider columnHeaderDataProvider, 
			ILayer bodyLayer,
			ConfigRegistry configRegistry) {
		
		ILayer columnHeaderLayer = super.createColumnHeaderLayer(
				columnHeaderDataProvider, bodyLayer, configRegistry);
		
		//add the SortHeaderLayer to the column header layer stack
		SortHeaderLayer<PersonWithAddress> sortHeaderLayer = new SortHeaderLayer<PersonWithAddress>(
				columnHeaderLayer, 
				new PersonWithAddressSortModel(
						((ListDataProvider<PersonWithAddress>)this.bodyDataLayer.getDataProvider()).getList()));
		//override the default sort configuration and change the mouse bindings to sort on a single click
		sortHeaderLayer.addConfiguration(new SingleClickSortConfiguration());

		return sortHeaderLayer;
	}
}
