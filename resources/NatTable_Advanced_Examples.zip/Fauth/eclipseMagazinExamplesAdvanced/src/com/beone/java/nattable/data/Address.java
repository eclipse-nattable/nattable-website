package com.beone.java.nattable.data;

public class Address {

	private String street;
	private Integer housenumber;
	private Integer postalCode;
	private String city;
	/**
	 * @return the street
	 */
	public String getStreet() {
		return street;
	}
	/**
	 * @param street the street to set
	 */
	public void setStreet(String street) {
		this.street = street;
	}
	/**
	 * @return the housenumber
	 */
	public int getHousenumber() {
		return housenumber;
	}
	/**
	 * @param housenumber the housenumber to set
	 */
	public void setHousenumber(Integer housenumber) {
		this.housenumber = housenumber;
	}
	/**
	 * @return the postalCode
	 */
	public int getPostalCode() {
		return postalCode;
	}
	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(Integer postalCode) {
		this.postalCode = postalCode;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	
	
}
