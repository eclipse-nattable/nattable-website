package com.beone.java.eclipsemagazinexamples.configuration;

import java.util.Comparator;

import net.sourceforge.nattable.config.AbstractRegistryConfiguration;
import net.sourceforge.nattable.config.IConfigRegistry;
import net.sourceforge.nattable.config.NullComparator;
import net.sourceforge.nattable.layer.AbstractLayer;
import net.sourceforge.nattable.layer.cell.ColumnOverrideLabelAccumulator;
import net.sourceforge.nattable.sort.SortConfigAttributes;
import net.sourceforge.nattable.style.DisplayMode;

import com.beone.java.eclipsemagazinexamples.data.DataModelConstants;

/**
 * NOTE: The labels for the the custom comparators must go on the columnHeaderDataLayer - since,
 * 		the SortHeaderLayer will resolve cell labels with respect to its underlying layer i.e columnHeaderDataLayer
 * 
 * 		By combining the setting of the labels and registering the comparators to the labels we have only
 * 		one class to search for the configuration. You could also set the sorting related labels within
 * 		an AbstractOverrider and only register the comparators here.
 */
public class CustomComparatorConfiguration extends AbstractRegistryConfiguration {

	private static final String CUSTOM_COMPARATOR_LABEL = "customComparatorLabel";
	private static final String NO_SORT_LABEL = "noSortLabel";

	private AbstractLayer columnHeaderDataLayer;
	
	public CustomComparatorConfiguration(AbstractLayer columnHeaderDataLayer) {
		this.columnHeaderDataLayer = columnHeaderDataLayer;
	}
	
	@Override
	public void configureRegistry(IConfigRegistry configRegistry) {
		// Add label accumulator
		ColumnOverrideLabelAccumulator labelAccumulator = new ColumnOverrideLabelAccumulator(columnHeaderDataLayer);
		columnHeaderDataLayer.setConfigLabelAccumulator(labelAccumulator);

		// Register labels
		labelAccumulator.registerColumnOverrides(
				DataModelConstants.FIRSTNAME_COLUMN_POSITION,
				CUSTOM_COMPARATOR_LABEL);
		labelAccumulator.registerColumnOverrides(
				DataModelConstants.LASTNAME_COLUMN_POSITION,
				CUSTOM_COMPARATOR_LABEL);

		labelAccumulator.registerColumnOverrides(
				DataModelConstants.HOUSENUMBER_COLUMN_POSITION,
				NO_SORT_LABEL);

		// Register custom comparator
		configRegistry.registerConfigAttribute(SortConfigAttributes.SORT_COMPARATOR,
				getIngnorecaseComparator(),
				DisplayMode.NORMAL,
				CUSTOM_COMPARATOR_LABEL);

		// Register null comparator to disable sort
		configRegistry.registerConfigAttribute(SortConfigAttributes.SORT_COMPARATOR,
				new NullComparator(),
				DisplayMode.NORMAL,
				NO_SORT_LABEL);
	}

	private Comparator<?> getIngnorecaseComparator() {
		return new Comparator<String>() {
			public int compare(String o1, String o2) {
				return o1.compareToIgnoreCase(o2);
			}
		};
	};
}
