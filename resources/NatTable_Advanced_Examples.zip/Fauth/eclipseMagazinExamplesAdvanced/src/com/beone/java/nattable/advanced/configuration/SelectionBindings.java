package com.beone.java.nattable.advanced.configuration;

import net.sourceforge.nattable.grid.GridRegion;
import net.sourceforge.nattable.selection.config.DefaultSelectionBindings;
import net.sourceforge.nattable.ui.action.IMouseAction;
import net.sourceforge.nattable.ui.binding.UiBindingRegistry;
import net.sourceforge.nattable.ui.matcher.MouseEventMatcher;
import net.sourceforge.nattable.viewport.ViewportLayer;

import org.eclipse.swt.SWT;

import com.beone.java.nattable.advanced.command.BodyPopupMouseSelectionAction;
import com.beone.java.nattable.advanced.command.SimpleMouseSelectionAction;

/**
 * Configuration class that overrides {@link DefaultSelectionBindings} to use the customized
 * {@link SimpleMouseSelectionAction} on left clicking within and opening a context menu on
 * right clicking the body of the grid.
 * 
 * @author Dirk Fauth
 *
 */
public class SelectionBindings extends DefaultSelectionBindings {

	private ViewportLayer viewPortLayer;
	
	public SelectionBindings(ViewportLayer viewPortLayer) {
		this.viewPortLayer = viewPortLayer;
	}
	
	/**
	 * On left mouse click, the special {@link SimpleMouseSelectionAction}
	 * will be called, on right click the {@link BodyPopupMouseSelectionAction}
	 * will be called.
	 */
	@Override
	protected void configureBodyMouseClickBindings(UiBindingRegistry uiBindingRegistry) {
		IMouseAction action = new SimpleMouseSelectionAction(viewPortLayer);
		uiBindingRegistry.registerMouseDownBinding(MouseEventMatcher.bodyLeftClick(SWT.NONE), action);
		uiBindingRegistry.registerMouseDownBinding(MouseEventMatcher.bodyLeftClick(SWT.SHIFT), action);
		uiBindingRegistry.registerMouseDownBinding(MouseEventMatcher.bodyLeftClick(SWT.CTRL), action);
		uiBindingRegistry.registerMouseDownBinding(MouseEventMatcher.bodyLeftClick(SWT.SHIFT | SWT.CONTROL), action);

		action = new BodyPopupMouseSelectionAction(viewPortLayer);
		uiBindingRegistry.registerMouseDownBinding(bodyRightClick(SWT.NONE), action);
		uiBindingRegistry.registerMouseDownBinding(bodyRightClick(SWT.SHIFT), action);
		uiBindingRegistry.registerMouseDownBinding(bodyRightClick(SWT.CTRL), action);
		uiBindingRegistry.registerMouseDownBinding(bodyRightClick(SWT.SHIFT | SWT.CONTROL), action);
	}
	
	public static MouseEventMatcher bodyRightClick(int mask) {
		return new MouseEventMatcher(mask, GridRegion.BODY, MouseEventMatcher.RIGHT_BUTTON);
	}

}
