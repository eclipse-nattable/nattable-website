package com.beone.java.eclipsemagazinexamples;

import java.util.HashMap;
import java.util.Map;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.data.ReflectiveColumnPropertyAccessor;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import com.beone.java.eclipsemagazinexamples.data.Person;
import com.beone.java.eclipsemagazinexamples.data.PersonService;

/**
 * Example that opens a window that shows a simple NatTable containing several simple POJOs of
 * type {@link Person}.
 * It uses the {@link DefaultGridLayer} for the {@link NatTable} which uses a 
 * {@link ReflectiveColumnPropertyAccessor} to access the data within a {@link ListDataProvider} within
 * the body region. 
 * The default implementation supports selection, scrolling, resizing and reordering.
 * 
 * @author Dirk H�u�ler
 */
public class SimpleNatTableExample {

	/**
	 * Opens a new window and shows a grid build with {@link SimpleNatTableExample#createControl(Composite)}
	 * @param args
	 */
	public static void main(String[] args) {
		final Display display = Display.getDefault();
		final Shell shell = new Shell(display, SWT.SHELL_TRIM);
		shell.setLayout(new FillLayout());
		shell.setSize(800, 600);
		shell.setText("Simple NatTable example");

		createControl(shell);
		
		shell.open();
		
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}

		shell.dispose();
		display.dispose();
	}

	/**
	 * Creates a simple {@link NatTable} with {@link DefaultGridLayer} that shows {@link Person}s.
	 * @param parent
	 * @return
	 */
	public static Control createControl(Composite parent) {
		//property names of the Person class
		String[] propertyNames = {"firstName", "lastName", "gender", "married", "birthday"};

		//mapping from property to label, needed for column header labels
		Map<String, String> propertyToLabelMap = new HashMap<String, String>();
		propertyToLabelMap.put("firstName", "Firstname");
		propertyToLabelMap.put("lastName", "Lastname");
		propertyToLabelMap.put("gender", "Gender");
		propertyToLabelMap.put("married", "Married");
		propertyToLabelMap.put("birthday", "Birthday");
		
		//create simple NatTable with DefaultGridLayer as underlying layer that shows Persons
		return new NatTable(parent, 
				new DefaultGridLayer(PersonService.getPersons(10), propertyNames, propertyToLabelMap));
	}
}
