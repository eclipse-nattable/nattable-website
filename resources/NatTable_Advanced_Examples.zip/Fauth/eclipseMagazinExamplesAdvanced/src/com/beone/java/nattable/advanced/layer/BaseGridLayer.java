package com.beone.java.nattable.advanced.layer;

import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.ExtendedReflectiveColumnPropertyAccessor;
import net.sourceforge.nattable.data.IColumnPropertyAccessor;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.data.ReflectiveColumnPropertyAccessor;
import net.sourceforge.nattable.grid.data.DefaultColumnHeaderDataProvider;
import net.sourceforge.nattable.grid.data.DefaultCornerDataProvider;
import net.sourceforge.nattable.grid.data.DefaultRowHeaderDataProvider;
import net.sourceforge.nattable.grid.layer.ColumnHeaderLayer;
import net.sourceforge.nattable.grid.layer.CornerLayer;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;
import net.sourceforge.nattable.grid.layer.GridLayer;
import net.sourceforge.nattable.grid.layer.RowHeaderLayer;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.ILayer;
import net.sourceforge.nattable.layer.config.DefaultColumnHeaderLayerConfiguration;
import net.sourceforge.nattable.layer.config.DefaultRowHeaderLayerConfiguration;
import net.sourceforge.nattable.selection.SelectionLayer;
import net.sourceforge.nattable.viewport.ViewportLayer;

import com.beone.java.nattable.advanced.configuration.CellLabelOverrider;
import com.beone.java.nattable.advanced.configuration.ColumnHeaderStyleConfiguration;
import com.beone.java.nattable.advanced.configuration.RowHeaderStyleConfiguration;
import com.beone.java.nattable.data.PersonWithAddress;

/**
 * Subclass of {@link GridLayer} which is functional almost the same as the {@link DefaultGridLayer}.
 * Wraps the creation of a grid to be easier to customize by overriding.
 * 
 * @author Dirk Fauth
 */
public class BaseGridLayer extends GridLayer {

	/**
	 * The {@link DataLayer} of the body layer stack
	 */
	protected DataLayer bodyDataLayer;
	
	/**
	 * The {@link DataLayer} of the column header layer stack
	 */
	protected DataLayer columnHeaderDataLayer;
	
	/**
	 * The {@link DataLayer} of the row header layer stack
	 */
	protected DataLayer rowHeaderDataLayer;
	
	/**
	 * The {@link SelectionLayer} of the body layer stack.
	 * Needed because the column and row header needs to react on selection within the body
	 * (showing the column and row selected if a cell is selected) and can be needed for additional
	 * functionality that depends on selection.
	 */
	protected SelectionLayer selectionLayer;
	
	/**
	 * The {@link IColumnPropertyAccessor} for accessing the object data.
	 * Needed as instance variable because of additional functionality in further examples.
	 */
	protected IColumnPropertyAccessor<PersonWithAddress> columnPropertyAccessor;
	
	/**
	 * String array with the property names of the model object.
	 */
	protected String[] propertyNames;
	
	/**
	 * Mapping from property name to column header label.
	 */
	protected Map<String, String> propertyToLabelMap;

	/**
	 * Creates at most a {@link DefaultGridLayer} expect that no {@link ReflectiveColumnPropertyAccessor}
	 * is used to access the data. Instead the {@link ExtendedReflectiveColumnPropertyAccessor} is used
	 * and the creation of the grid is separated in different methods so overriding and adjusting is easier.
	 * @param values the list of the objects to show within the NatTable
	 * @param propertyNames String array with the property names of the model T
	 * @param propertyToLabelMap mapping from property name to column header label
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 */
	public BaseGridLayer(
			List<PersonWithAddress> values, 
			String[] propertyNames,
			Map<String, String> propertyToLabelMap, 
			ConfigRegistry configRegistry) {
		
		//use default configuration which adds default editing, excel export, print
		//and alternate row coloring configurations
		super(true);
		
		this.propertyNames = propertyNames;
		this.propertyToLabelMap = propertyToLabelMap;

		columnPropertyAccessor = new ExtendedReflectiveColumnPropertyAccessor<PersonWithAddress>(propertyNames);

		BodyLayerStack bodyLayer = createBodyLayerStack(values);
		setBodyLayer(bodyLayer);
		
		ILayer columnHeaderLayer = createColumnHeaderLayer(
				bodyLayer, 
				configRegistry);
		setColumnHeaderLayer(columnHeaderLayer);

		ILayer rowHeaderLayer = createRowHeaderLayer(
				bodyLayer);
		setRowHeaderLayer(rowHeaderLayer);
		
		//create DefaultCornerDataProvider which simply returns nothing, which means the
		//corner is empty
		IDataProvider cornerDataProvider = 
			new DefaultCornerDataProvider(
					columnHeaderDataLayer.getDataProvider(), rowHeaderDataLayer.getDataProvider());
		
		setCornerLayer(createCornerLayer(cornerDataProvider));
	}
	
	/**
	 * Creates the layer stack for the body region of this {@link GridLayer}.
	 * The default implementation shows the values of the objects accessed by the {@link IDataProvider}
	 * and supports selection, reordering and hide/show of columns. As the top layer of the
	 * body layer stack has to be a {@link ViewportLayer} it is scrollable, resizable and is
	 * virtual.
	 * @param values the list of the objects to show within the NatTable
	 * @return The layer stack for the body region of this {@link GridLayer}
	 */
	protected BodyLayerStack createBodyLayerStack(List<PersonWithAddress> values) {
		bodyDataLayer = new DataLayer(new ListDataProvider<PersonWithAddress>(values, columnPropertyAccessor));
		
		bodyDataLayer.setConfigLabelAccumulator(
				new CellLabelOverrider(bodyDataLayer.getDataProvider()));
		
		BodyLayerStack bodyLayer = new BodyLayerStack(bodyDataLayer);
		selectionLayer = bodyLayer.getSelectionLayer();
		return bodyLayer;
	}
	
	/**
	 * Creates the layer stack for the column header region of this {@link GridLayer}.
	 * The default implementation shows the column names defined by the data provider and
	 * supports selection, resizing and reordering by drag and drop.  
	 * This specialization adds custom styling configuration to the column header.
	 * @param bodyLayer The body layer stack to which the column header should be dimensional dependent
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 * @return The layer stack for the column header region of this {@link GridLayer}
	 */
	protected ILayer createColumnHeaderLayer(
			BodyLayerStack bodyLayer,
			ConfigRegistry configRegistry) {
		//create the data layer
		columnHeaderDataLayer = new DataLayer(
				new DefaultColumnHeaderDataProvider(propertyNames, propertyToLabelMap), 100, 20);
		//create a default column header layer for the given data layer and the dependency on the body layer
		//and don't use the default configuration
		ColumnHeaderLayer columnHeaderLayer = 
			new ColumnHeaderLayer(columnHeaderDataLayer, bodyLayer, selectionLayer, false);
		//add your special configuration for customizing
		columnHeaderLayer.addConfiguration(new DefaultColumnHeaderLayerConfiguration() {

			@Override
			protected void addColumnHeaderStyleConfig() {
				addConfiguration(new ColumnHeaderStyleConfiguration());
			}

		});
		return columnHeaderLayer;
	}
	
	/**
	 * Creates the layer stack for the row header region of this {@link GridLayer}.
	 * The default implementation shows the values of the data provider and supports selection
	 * and resizing.
	 * This specialization adds custom styling configuration to the row header.
	 * @param bodyLayer The body layer stack to which the row header should be dimensional dependent
	 * @return The layer stack for the row header region of this {@link GridLayer}
	 */
	protected ILayer createRowHeaderLayer(
			ILayer bodyLayer) {
		//create the data layer
		rowHeaderDataLayer = new DataLayer(
				new DefaultRowHeaderDataProvider(bodyDataLayer.getDataProvider()), 20, 20);
		//create a default row header layer for the given data layer and the dependency on the body layer
		//and don't use the default configuration
		RowHeaderLayer rowHeaderLayer = 
			new RowHeaderLayer(rowHeaderDataLayer, bodyLayer, selectionLayer, false);
		//add your special configuration for customizing
		rowHeaderLayer.addConfiguration(new DefaultRowHeaderLayerConfiguration() {
			
			@Override
			protected void addRowHeaderStyleConfig() {
				addConfiguration(new RowHeaderStyleConfiguration());
			}
			
		});
		return rowHeaderLayer;
	}
	
	/**
	 * Creates the layer stack for the corner region of this {@link GridLayer}.
	 * It only consists of a DataLayer that wraps an IDataProvider and is dimensionally
	 * dependent to the row header and the column header. 
	 * The corner of a grid does not support functionality by default.
	 * @param cornerDataProvider The {@link IDataProvider} for the corner layer.
	 * @return The layer stack for the corner region of this {@link GridLayer}.
	 */
	protected ILayer createCornerLayer(IDataProvider cornerDataProvider) {
		//create the DataLayer for the corner region with default width and height
		DataLayer cornerDataLayer = new DataLayer(cornerDataProvider, 20, 20);
		return new CornerLayer(cornerDataLayer, getRowHeaderLayer(), getColumnHeaderLayer());
	}

	/**
	 * @return The {@link DataLayer} for the body region of this {@link GridLayer}
	 */
	public DataLayer getBodyDataLayer() {
		return this.bodyDataLayer;
	}
	
	/**
	 * @return The {@link DataLayer} for the column header region of this {@link GridLayer}
	 */
	public DataLayer getColumnHeaderDataLayer() {
		return this.columnHeaderDataLayer;
	}
}
