package com.beone.java.nattable.advanced.command;

import java.util.ArrayList;
import java.util.List;

import net.sourceforge.nattable.command.ILayerCommandHandler;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsEventLayer;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.ILayer;
import ca.odell.glazedlists.EventList;

import com.beone.java.nattable.data.PersonWithAddress;

/**
 * Command handler that will handle {@link DeleteRowCommand} objects.
 * Is instantiated with the {@link DataLayer} of the body and the {@link EventList}
 * that contains the data shown within the NatTable.
 * If this command handler is called with a {@link DeleteRowCommand}, all objects
 * identified by the row indexes carried by the command will be removed from the
 * {@link EventList}. As we know that the body contains a {@link GlazedListsEventLayer}
 * we don't have to call a refresh event ourself.
 * 
 * @author Dirk Fauth
 *
 */
public class DeleteRowCommandHandler implements ILayerCommandHandler<DeleteRowCommand> {

	private DataLayer bodyDataLayer;
	private EventList<PersonWithAddress> eventList;
	
	public DeleteRowCommandHandler(DataLayer bodyDataLayer, EventList<PersonWithAddress> eventList) {
		this.bodyDataLayer = bodyDataLayer;
		this.eventList = eventList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean doCommand(ILayer targetLayer, DeleteRowCommand command) {
		int[] rowIndexes = command.getRowIndexes();
		List<PersonWithAddress> toDelete = new ArrayList<PersonWithAddress>(); 
		for (int rowIndex : rowIndexes) {
			toDelete.add(((IRowDataProvider<PersonWithAddress>) 
					bodyDataLayer.getDataProvider()).getRowObject(rowIndex));
		}
		
		eventList.removeAll(toDelete);

		//this is not necessary as we use the GlazedListsEventLayer that informs
		//all other layers about structural changes within the list. If you don't
		//use GlazedLists you will have to fire the StructuralRefreshEvent by yourself!
//		bodyDataLayer.fireLayerEvent(new StructuralRefreshEvent(bodyDataLayer));
		
		return true;
	}
	
	@Override
	public Class<DeleteRowCommand> getCommandClass() {
		return DeleteRowCommand.class;
	}

}
