package com.beone.java.eclipsemagazinexamples.configuration;

import net.sourceforge.nattable.layer.config.DefaultColumnHeaderStyleConfiguration;
import net.sourceforge.nattable.painter.cell.TextPainter;
import net.sourceforge.nattable.painter.cell.decorator.BeveledBorderDecorator;
import net.sourceforge.nattable.style.HorizontalAlignmentEnum;
import net.sourceforge.nattable.style.VerticalAlignmentEnum;
import net.sourceforge.nattable.util.GUIHelper;

/**
 * Simple style configuration for the column header of a grid.
 * Extends {@link DefaultColumnHeaderStyleConfiguration} so we only have to adjust the
 * style properties instead of creating a completely new configuration.
 * @author Dirk H�u�ler
 */
public class ColumnHeaderStyleConfiguration extends DefaultColumnHeaderStyleConfiguration {

	{
		//all attributes overriden here for showing completely, wouldn't be necessary
		this.font = GUIHelper.DEFAULT_FONT;
		this.bgColor = GUIHelper.COLOR_WIDGET_BACKGROUND;
		this.fgColor = GUIHelper.COLOR_WIDGET_FOREGROUND;
		this.hAlign = HorizontalAlignmentEnum.CENTER;
		this.vAlign = VerticalAlignmentEnum.MIDDLE;
		this.borderStyle = null;

		//the painter used for rendering the cells of the column header
		this.cellPainter = new BeveledBorderDecorator(new TextPainter());
	}
}
