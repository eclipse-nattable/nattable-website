package com.beone.java.nattable.advanced.layer;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsDataProvider;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsEventLayer;
import net.sourceforge.nattable.extension.glazedlists.tree.GlazedListTreeData;
import net.sourceforge.nattable.extension.glazedlists.tree.GlazedListTreeRowModel;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;
import net.sourceforge.nattable.grid.layer.GridLayer;
import net.sourceforge.nattable.layer.DataLayer;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.SortedList;
import ca.odell.glazedlists.TransformedList;
import ca.odell.glazedlists.TreeList;
import ca.odell.glazedlists.TreeList.ExpansionModel;

import com.beone.java.nattable.advanced.configuration.CellLabelOverrider;
import com.beone.java.nattable.data.PersonWithAddress;

public class TreeGridLayer extends SortableGridLayer {

	/**
	 * Reference to the tree list which wraps the original data list.
	 */
	protected TreeList<PersonWithAddress> treeList;

	/**
	 * Creates a {@link GridLayer} that has all functionality a {@link DefaultGridLayer} has,
	 * adding custom data access, styling and sorting to the NatTable.
	 * @param values the list of the objects to show within the NatTable
	 * @param propertyNames String array with the property names of the model T
	 * @param propertyToLabelMap mapping from property name to column header label
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 */
	public TreeGridLayer(
			List<PersonWithAddress> values, 
			String[] propertyNames,
			Map<String, String> propertyToLabelMap, 
			ConfigRegistry configRegistry) {
		super(values, propertyNames, propertyToLabelMap, configRegistry);
	}
	
	/**
	 * {@inheritDoc}
	 * To handle events fired by {@link GlazedLists} automatically, we add the {@link GlazedListsEventLayer}
	 * on top of the {@link DataLayer} before we add other functional layer. This way we don't have to
	 * handle those events manually to update the view on structural data changes.
	 */
	@Override
	protected BodyLayerStack createBodyLayerStack(List<PersonWithAddress> values) {
		//wrapping of the data list into GlazedLists
		//see http://publicobject.com/glazedlists/ for further information
		EventList<PersonWithAddress> eventList = GlazedLists.eventList(values);
		TransformedList<PersonWithAddress, PersonWithAddress> rowObjectsGlazedList = GlazedLists.threadSafeList(eventList);
		
		//use the SortedList constructor with 'null' for the Comparator because the Comparator
		//will be set by configuration
		sortedList = new SortedList<PersonWithAddress>(rowObjectsGlazedList, null);
		
		treeList = new TreeList<PersonWithAddress>(sortedList, 
				new PersonWithAddressTreeFormat(), new PersonWithAddressExpansionModel());
		
		IDataProvider bodyDataProvider = 
			new GlazedListsDataProvider<PersonWithAddress>(treeList, columnPropertyAccessor);

		bodyDataLayer = new DataLayer(bodyDataProvider);
		bodyDataLayer.setConfigLabelAccumulator(new CellLabelOverrider(bodyDataProvider));
		
		//layer for event handling of GlazedLists and PropertyChanges
		GlazedListsEventLayer<PersonWithAddress> glazedListsEventLayer = 
			new GlazedListsEventLayer<PersonWithAddress>(bodyDataLayer, sortedList);
		
		GlazedListTreeData<PersonWithAddress> treeData = new GlazedListTreeData<PersonWithAddress>(treeList) {
			@Override
			public String formatDataForDepth(int depth, PersonWithAddress object) {
				return object.getLastName();
			}
		};
		BodyLayerStack bodyLayerStack = new BodyLayerStack(glazedListsEventLayer, new GlazedListTreeRowModel<PersonWithAddress>(treeData));
		selectionLayer = bodyLayerStack.getSelectionLayer();
		return bodyLayerStack;
	}

	
	private class PersonWithAddressTreeFormat implements TreeList.Format<PersonWithAddress> {
		
		private Map<String, PersonWithAddress> parentMapping = new HashMap<String, PersonWithAddress>();
		
		/**
		 * Populate path with a list describing the path from a root node to this element. 
		 * Upon returning, the list must have size >= 1, where the provided element identical to the 
		 * list's last element.
		 * This implementation will use the first object found for a last name as root node by
		 * storing it within a map. If there is already an object stored for the lastname of the
		 * given element, it will be used as root for the path.
		 */
		public void getPath(List<PersonWithAddress> path, PersonWithAddress element) {
			if (parentMapping.get(element.getLastName()) != null) {
				path.add(parentMapping.get(element.getLastName()));
			}
			else {
				parentMapping.put(element.getLastName(), element);
			}
			path.add(element);
		}
		
		/**
		 * Simply always return <code>true</code>.
		 * @return <code>true</code> if this element can have child elements, 
		 * 			or <code>false</code> if it is always a leaf node.
		 */
		public boolean allowsChildren(PersonWithAddress element) {
			return true;
		}

		/**
		 * Returns the comparator used to order path elements of the specified depth. 
		 * If enforcing order at this level is not intended, this method should return <code>null</code>.
		 * We do a simple sorting of the last names of the persons to show so the tree nodes
		 * are sorted in alphabetical order.
		 */
		public Comparator<? extends PersonWithAddress> getComparator(int depth) {
			return new Comparator<PersonWithAddress>() {

				@Override
				public int compare(PersonWithAddress o1, PersonWithAddress o2) {
					return o1.getLastName().compareTo(o2.getLastName());
				}
				
			};
		}
	}

	/**
	 * Simple {@link ExpansionModel} that shows every node expanded initially and doesn't react on
	 * expand/collapse state changes.
	 * 
	 * It is not strictly necessary for implementors to record the expand/collapsed state of all nodes, 
	 * since TreeList caches node state internally.
	 * 
	 * @see http://publicobject.com/glazedlists/glazedlists-1.8.0/api/ca/odell/glazedlists/TreeList.ExpansionModel.html
	 */
	private class PersonWithAddressExpansionModel implements TreeList.ExpansionModel<PersonWithAddress> {
		/**
		 * Determine the specified element's initial expand/collapse state.
		 */
		public boolean isExpanded(PersonWithAddress element, List<PersonWithAddress> path) {
			return true;
		}

		/**
		 * Notifies this handler that the specified element's expand/collapse state has changed.
		 */
		public void setExpanded(PersonWithAddress element,	List<PersonWithAddress> path, boolean expanded) {
		}
	}
}
