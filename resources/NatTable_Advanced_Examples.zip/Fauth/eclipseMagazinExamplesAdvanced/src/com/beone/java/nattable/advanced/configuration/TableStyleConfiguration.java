package com.beone.java.nattable.advanced.configuration;

import net.sourceforge.nattable.config.AbstractRegistryConfiguration;
import net.sourceforge.nattable.config.CellConfigAttributes;
import net.sourceforge.nattable.config.IConfigRegistry;
import net.sourceforge.nattable.painter.cell.CheckBoxPainter;
import net.sourceforge.nattable.style.DisplayMode;

import com.beone.java.nattable.data.Person;

/**
 * Style configurations for conditional styling.
 * Adds a yellow background style to cells that show a {@link Person.Gender#FEMALE}
 * and sets a {@link CheckBoxPainter} to cells that show the married information of
 * a {@link Person}.
 * 
 * @author Dirk Fauth
 */
public class TableStyleConfiguration extends AbstractRegistryConfiguration {

	@Override
	public void configureRegistry(IConfigRegistry configRegistry) {
		
		//register a CheckBoxPainter as CellPainter for the married information
		configRegistry.registerConfigAttribute(
				CellConfigAttributes.CELL_PAINTER, 
				new CheckBoxPainter(), 
				DisplayMode.NORMAL, 
				CellLabelOverrider.MARRIED_LABEL);

	}

}
