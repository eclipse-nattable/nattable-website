package com.beone.java.nattable.advanced.command;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.command.ILayerCommand;
import net.sourceforge.nattable.command.LayerCommandUtil;
import net.sourceforge.nattable.coordinate.RowPositionCoordinate;
import net.sourceforge.nattable.selection.action.AbstractMouseSelectionAction;
import net.sourceforge.nattable.viewport.ViewportLayer;
import net.sourceforge.nattable.viewport.command.ViewportSelectRowCommand;

import org.eclipse.swt.events.MouseEvent;

/**
 * Simple action that can be used to select/unselect objects within a NatTable
 * where row selection is enabled. Checks whether the selected row is already
 * selected, and if so removes the selection.
 * 
 * @author Dirk Fauth
 *
 */
public class SimpleMouseSelectionAction extends AbstractMouseSelectionAction {
    
	protected ViewportLayer viewPortLayer;
	
	public SimpleMouseSelectionAction(ViewportLayer viewPortLayer) {
		this.viewPortLayer = viewPortLayer;
	}
	
	@Override
	public void run(NatTable natTable, MouseEvent event) {
    	super.run(natTable, event);
    	
		boolean controlMask = isWithControlMask();
    
		if (isSingleRowFullySelected(natTable)) {
			//we are simply faking the control key pressed so it works like we want to ;)
			controlMask = true;  		
		}
		
		ILayerCommand command = new ViewportSelectRowCommand(
				natTable, 
				getGridRowPosition(), 
				isWithShiftMask(), 
				controlMask);
	
        natTable.doCommand(command);
    }

    /**
     * Checks if the row at the current grid row position is fully selected.
     * To do this we calculate the row position of the selection layer with 
     * the grid row position.
     * @param natTable the current {@link NatTable} which is base for the grid row position
     * @return true if the row which should be selected is already selected and it is
     * 			the only row that is selected, false if the row isn't selected yet or more than
     * 			one row is selected
     */
    protected boolean isSingleRowFullySelected(NatTable natTable) {
    	boolean result = false;
    	
		//check current selection
    	RowPositionCoordinate coord = LayerCommandUtil.convertRowPositionToTargetContext(
    			new RowPositionCoordinate(natTable, getGridRowPosition()), viewPortLayer);
    	if (viewPortLayer != null && 
    			viewPortLayer.getSelectionLayer().getSelectedRowCount() == 1 && 
    			viewPortLayer.getSelectionLayer().isRowPositionFullySelected(coord.rowPosition)) {
			result = true;
		}
    	
    	return result;
    }

}
