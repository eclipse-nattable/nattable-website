package com.beone.java.eclipsemagazinexamples.layer;

import net.sourceforge.nattable.copy.command.CopyDataCommandHandler;
import net.sourceforge.nattable.hideshow.ColumnHideShowLayer;
import net.sourceforge.nattable.layer.AbstractLayerTransform;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.IUniqueIndexLayer;
import net.sourceforge.nattable.layer.stack.DefaultBodyLayerStack;
import net.sourceforge.nattable.reorder.ColumnReorderLayer;
import net.sourceforge.nattable.selection.SelectionLayer;
import net.sourceforge.nattable.selection.config.DefaultSelectionLayerConfiguration;
import net.sourceforge.nattable.viewport.ViewportLayer;

import com.beone.java.eclipsemagazinexamples.configuration.SelectionStyleConfiguration;

/**
 * The StyledBodyLayerStack consists of the following layers:<br/>
 * {@link ViewportLayer}<br/>
 * {@link SelectionLayer}<br/>
 * {@link ColumnHideShowLayer}<br/>
 * {@link ColumnReorderLayer}<br/>
 * They are build uppon a layer which has to be given as parameter when
 * creating the StyledBodyLayerStack. Normally this should be a {@link DataLayer}
 * that contains the data to be shown.
 * The StyledBodyLayerStack has the same structure like the {@link DefaultBodyLayerStack}
 * except that the {@link SelectionLayer} has different styling.
 * @author Dirk H�u�ler
 */
public class StyledBodyLayerStack extends AbstractLayerTransform {

	/**
	 * Layer that adds the functionality of column reordering
	 */
	private final ColumnReorderLayer columnReorderLayer;
	
	/**
	 * Layer that adds the functionality of hiding/showing columns
	 */
	private final ColumnHideShowLayer columnHideShowLayer;
	
	/**
	 * Layer that enables selection
	 */
	private final SelectionLayer selectionLayer;
	
	/**
	 * Layer that handles the visible part of the NatTable.
	 * This one makes the NatTable VIRTUAL.
	 */
	private final ViewportLayer viewportLayer;

	/**
	 * Creates a new {@link StyledBodyLayerStack} on top of the given layer.
	 * It is almost the same as a {@link DefaultBodyLayerStack} except that
	 * the {@link SelectionLayer} has another styling.
	 * @param underlyingLayer The layer on which this body layer should be build.
	 * Normally the underlying layer is a {@link DataLayer}.
	 */
	public StyledBodyLayerStack(IUniqueIndexLayer underlyingLayer) {
		columnReorderLayer = new ColumnReorderLayer(underlyingLayer);
		columnHideShowLayer = new ColumnHideShowLayer(columnReorderLayer);
		
		//creation of the SelectionLayer without default configuration
		selectionLayer = new SelectionLayer(columnHideShowLayer, false);
		//adding customized configuration
		selectionLayer.addConfiguration(new DefaultSelectionLayerConfiguration() {

			@Override
			protected void addSelectionStyleConfig() {
				addConfiguration(new SelectionStyleConfiguration());
			}

		});
		
		viewportLayer = new ViewportLayer(selectionLayer);
		
		//as this layer stack is a layer itself, we have to set the ViewportLayer
		//as underlying layer to match the NatTable architecture
		setUnderlyingLayer(viewportLayer);

		//add the command handler to support copying selected data into the clipboard
		//the action that triggers the execution of this command handler is configured
		//within the DefaultSelectionBindings of the SelectionLayer
		registerCommandHandler(new CopyDataCommandHandler(selectionLayer));
	}

	/**
	 * @return The {@link ColumnReorderLayer} of this body layer stack
	 */
	public ColumnReorderLayer getColumnReorderLayer() {
		return columnReorderLayer;
	}

	/**
	 * @return The {@link ColumnHideShowLayer} of this body layer stack
	 */
	public ColumnHideShowLayer getColumnHideShowLayer() {
		return columnHideShowLayer;
	}

	/**
	 * @return The {@link SelectionLayer} of this body layer stack
	 */
	public SelectionLayer getSelectionLayer() {
		return selectionLayer;
	}

	/**
	 * @return The {@link ViewportLayer} of this body layer stack
	 */
	public ViewportLayer getViewportLayer() {
		return viewportLayer;
	}
}
