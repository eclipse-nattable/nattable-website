package com.beone.java.nattable.data;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import net.sourceforge.nattable.data.convert.DisplayConverter;
import net.sourceforge.nattable.util.ObjectUtils;

/**
 * Converts a java.util.Date object to a given format and vice versa
 * 
 * Works like the DefaultDisplayConverter from NatTable except that exceptions
 * that occured while converting the data are not printed to the console.
 * Better solution would be to capsule the Exceptions in RuntimeExceptions
 * that should be handled by the TextCellEditor as failure.
 * 
 * <p>API change in NatTable version 2.3.0 
 * @see http://sourceforge.net/projects/nattable/forums/forum/744992/topic/4726129
 */
public class DateDisplayConverter extends DisplayConverter {

	private DateFormat dateFormat;

	/**
	 * Convert {@link Date} to {@link String} using the default format from {@link SimpleDateFormat}
	 */
	public DateDisplayConverter() {
		this(null, null);
	}
	
	public DateDisplayConverter(TimeZone timeZone) {
		this(null, timeZone);
	}

	/**
	 * @param dateFormat as specified in {@link SimpleDateFormat}
	 */
	public DateDisplayConverter(String dateFormat) {
		this(dateFormat, null);
	}
	
	public DateDisplayConverter(String dateFormat, TimeZone timeZone) {
		if (dateFormat != null) {
			this.dateFormat = new SimpleDateFormat(dateFormat);
		} else {
			this.dateFormat = new SimpleDateFormat();
		}
		
		if (timeZone != null) {
			this.dateFormat.setTimeZone(timeZone);
		}
	}

	@Override
	public Object canonicalToDisplayValue(Object canonicalValue) {
		try {
			if (ObjectUtils.isNotNull(canonicalValue)) {
				return dateFormat.format(canonicalValue);
			}
		} catch (Exception e) {
			//do nothing, validator will show the error
		}
		return canonicalValue;
	}

	@Override
	public Object displayToCanonicalValue(Object displayValue) {
		try {
			return dateFormat.parse(displayValue.toString());
		} catch (Exception e) {
			//do nothing, validator will show the error
		}
		return displayValue;
	}

}
