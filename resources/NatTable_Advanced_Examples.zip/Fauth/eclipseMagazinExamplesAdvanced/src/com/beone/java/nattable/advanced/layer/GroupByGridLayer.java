package com.beone.java.nattable.advanced.layer;

import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsEventLayer;
import net.sourceforge.nattable.extension.glazedlists.groupBy.GroupByDataLayer;
import net.sourceforge.nattable.extension.glazedlists.groupBy.GroupByModel;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;
import net.sourceforge.nattable.grid.layer.GridLayer;
import net.sourceforge.nattable.layer.DataLayer;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedLists;

import com.beone.java.nattable.advanced.configuration.CellLabelOverrider;
import com.beone.java.nattable.data.PersonWithAddress;

/**
 * Subclass of the {@link BaseGridLayer} that adds group by functionality.
 * 
 * @author Dirk Fauth
 * 
 */
public class GroupByGridLayer extends BaseGridLayer {

	protected GroupByModel groupByModel;

	/**
	 * Creates a {@link GridLayer} that has all functionality a
	 * {@link DefaultGridLayer} has, adding custom data access, styling and
	 * sorting to the NatTable.
	 * 
	 * @param values
	 *            the list of the objects to show within the NatTable
	 * @param propertyNames
	 *            String array with the property names of the model T
	 * @param propertyToLabelMap
	 *            mapping from property name to column header label
	 * @param configRegistry
	 *            the config registry, needed for additional functionality
	 *            configuration, e.g. sorting
	 */
	public GroupByGridLayer(List<PersonWithAddress> values,
			String[] propertyNames, Map<String, String> propertyToLabelMap,
			ConfigRegistry configRegistry) {
		super(values, propertyNames, propertyToLabelMap, configRegistry);
	}

	/**
	 * {@inheritDoc} To handle events fired by {@link GlazedLists}
	 * automatically, we add the {@link GlazedListsEventLayer} on top of the
	 * {@link DataLayer} before we add other functional layer. This way we don't
	 * have to handle those events manually to update the view on structural
	 * data changes.
	 */
	@SuppressWarnings({ "unchecked" })
	@Override
	protected BodyLayerStack createBodyLayerStack(List<PersonWithAddress> values) {
		// wrapping of the data list into GlazedLists
		// see http://publicobject.com/glazedlists/ for further information
		EventList<PersonWithAddress> eventList = GlazedLists.eventList(values);

		groupByModel = new GroupByModel();
		bodyDataLayer = new GroupByDataLayer<PersonWithAddress>(groupByModel,
				eventList, columnPropertyAccessor);

		bodyDataLayer.setConfigLabelAccumulator(new CellLabelOverrider(
				bodyDataLayer.getDataProvider()));

		BodyLayerStack bodyLayerStack = new BodyLayerStack(bodyDataLayer,
				((GroupByDataLayer<PersonWithAddress>) bodyDataLayer)
						.getTreeRowModel());
		selectionLayer = bodyLayerStack.getSelectionLayer();
		return bodyLayerStack;
	}

	public GroupByModel getGroupByModel() {
		return this.groupByModel;
	}
}
