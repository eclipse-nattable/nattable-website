package com.beone.java.nattable.advanced.layer;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.IColumnPropertyAccessor;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsDataProvider;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsEventLayer;
import net.sourceforge.nattable.extension.glazedlists.tree.GlazedListTreeData;
import net.sourceforge.nattable.extension.glazedlists.tree.GlazedListTreeRowModel;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;
import net.sourceforge.nattable.grid.layer.GridLayer;
import net.sourceforge.nattable.layer.DataLayer;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.SortedList;
import ca.odell.glazedlists.TransformedList;
import ca.odell.glazedlists.TreeList;

import com.beone.java.nattable.advanced.configuration.CellLabelOverrider;
import com.beone.java.nattable.data.PersonWithAddress;

public class TreeGridLayer2 extends SortableGridLayer {

	/**
	 * Reference to the tree list which wraps the original data list.
	 */
	protected TreeList<Object> treeList;

	/**
	 * Creates a {@link GridLayer} that has all functionality a {@link DefaultGridLayer} has,
	 * adding custom data access, styling and sorting to the NatTable.
	 * @param values the list of the objects to show within the NatTable
	 * @param propertyNames String array with the property names of the model T
	 * @param propertyToLabelMap mapping from property name to column header label
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 */
	public TreeGridLayer2(
			List<PersonWithAddress> values, 
			String[] propertyNames,
			Map<String, String> propertyToLabelMap, 
			ConfigRegistry configRegistry) {
		super(values, propertyNames, propertyToLabelMap, configRegistry);
	}
	
	/**
	 * {@inheritDoc}
	 * To handle events fired by {@link GlazedLists} automatically, we add the {@link GlazedListsEventLayer}
	 * on top of the {@link DataLayer} before we add other functional layer. This way we don't have to
	 * handle those events manually to update the view on structural data changes.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	protected BodyLayerStack createBodyLayerStack(List<PersonWithAddress> values) {
		//wrapping of the data list into GlazedLists
		//see http://publicobject.com/glazedlists/ for further information
		EventList<PersonWithAddress> eventList = GlazedLists.eventList(values);
		TransformedList<PersonWithAddress, PersonWithAddress> rowObjectsGlazedList = GlazedLists.threadSafeList(eventList);
		
		//use the SortedList constructor with 'null' for the Comparator because the Comparator
		//will be set by configuration
		sortedList = new SortedList<PersonWithAddress>(rowObjectsGlazedList, null);
		
		TreeList.ExpansionModel<Object> treeExpansionModel = new TreeList.ExpansionModel<Object>() {
			public boolean isExpanded(Object arg0, List<Object> arg1) {
				return true;
			}
			public void setExpanded(Object arg0, List<Object> arg1, boolean arg2) {
			}
		};
		
		treeList = new TreeList(sortedList, 
				new PersonWithAddressTreeFormat(), treeExpansionModel);
		
		IDataProvider bodyDataProvider = 
			new GlazedListsDataProvider<Object>(treeList, 
					new PersonWithAddressTreeColumnPropertyAccessor(columnPropertyAccessor));

		bodyDataLayer = new DataLayer(bodyDataProvider);
		bodyDataLayer.setConfigLabelAccumulator(new CellLabelOverrider(bodyDataProvider));
		
		//layer for event handling of GlazedLists and PropertyChanges
		GlazedListsEventLayer<PersonWithAddress> glazedListsEventLayer = 
			new GlazedListsEventLayer<PersonWithAddress>(bodyDataLayer, sortedList);
		
		GlazedListTreeData<Object> treeData = new GlazedListTreeData<Object>(treeList) {
			@Override
			public String formatDataForDepth(int depth, Object object) {
				if (object instanceof PersonWithAddress) {
					return ((PersonWithAddress)object).getLastName();
				}
				return object.toString();
			}
		};
		BodyLayerStack bodyLayerStack = new BodyLayerStack(glazedListsEventLayer, 
				new GlazedListTreeRowModel<Object>(treeData));
		selectionLayer = bodyLayerStack.getSelectionLayer();
		return bodyLayerStack;
	}

	
	private class PersonWithAddressTreeColumnPropertyAccessor implements IColumnPropertyAccessor<Object> {

		private IColumnPropertyAccessor<PersonWithAddress> cpa;
		
		public PersonWithAddressTreeColumnPropertyAccessor(IColumnPropertyAccessor<PersonWithAddress> cpa) {
			this.cpa = cpa;
		}
		
		@Override
		public Object getDataValue(Object rowObject, int columnIndex) {
			if (rowObject instanceof PersonWithAddress) {
				return this.cpa.getDataValue((PersonWithAddress)rowObject, columnIndex);
			}
			else if (columnIndex == 0) {
				return rowObject;
			}
			return null;
		}

		@Override
		public void setDataValue(Object rowObject, int columnIndex, Object newValue) {
			if (rowObject instanceof PersonWithAddress) {
				this.cpa.setDataValue((PersonWithAddress)rowObject, columnIndex, newValue);
			}
		}

		@Override
		public int getColumnCount() {
			return this.cpa.getColumnCount();
		}

		@Override
		public String getColumnProperty(int columnIndex) {
			return this.cpa.getColumnProperty(columnIndex);
		}

		@Override
		public int getColumnIndex(String propertyName) {
			return this.cpa.getColumnIndex(propertyName);
		}
		
	}
	
	private class PersonWithAddressTreeFormat implements TreeList.Format<Object> {
		
		public void getPath(List<Object> path, Object element) {
			if (element instanceof PersonWithAddress) {
				PersonWithAddress ele = (PersonWithAddress) element;
				path.add(ele.getLastName());
			}
			path.add(element);
		}
		
		public boolean allowsChildren(Object element) {
			return true;
		}

		public Comparator<? extends Object> getComparator(int depth) {
			return new Comparator<Object>() {

				@Override
				public int compare(Object o1, Object o2) {
					String e1 = (o1 instanceof PersonWithAddress) ? ((PersonWithAddress)o1).getLastName() : o1.toString();
					String e2 = (o2 instanceof PersonWithAddress) ? ((PersonWithAddress)o2).getLastName() : o2.toString();
					return e1.compareTo(e2);
				}
				
			};
		}
	}
}
