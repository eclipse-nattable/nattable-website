package com.beone.java.nattable.advanced.configuration;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.ui.menu.HeaderMenuConfiguration;
import net.sourceforge.nattable.ui.menu.PopupMenuBuilder;

/**
 * Overrides the {@link HeaderMenuConfiguration} to disable column renaming and
 * cell styling which is contained in the default configuration.
 * @author Dirk Fauth
 */
public class CustomHeaderMenuConfiguration extends HeaderMenuConfiguration {

	public CustomHeaderMenuConfiguration(NatTable natTable) {
		super(natTable);
	}
	
	@Override
	protected PopupMenuBuilder createColumnHeaderMenu(NatTable natTable) {
		return new PopupMenuBuilder(natTable)
								.withHideColumnMenuItem()
								.withShowAllColumnsMenuItem()
								.withCreateColumnGroupsMenuItem()
								.withUngroupColumnsMenuItem()
								.withColumnChooserMenuItem()
								.withAutoResizeSelectedColumnsMenuItem()
								.withColumnRenameDialog();
	}
}
