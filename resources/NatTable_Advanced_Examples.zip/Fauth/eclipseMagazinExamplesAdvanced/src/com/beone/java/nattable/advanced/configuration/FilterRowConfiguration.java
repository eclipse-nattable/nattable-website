package com.beone.java.nattable.advanced.configuration;

import static net.sourceforge.nattable.filterrow.config.FilterRowConfigAttributes.TEXT_MATCHING_MODE;

import java.util.Arrays;

import net.sourceforge.nattable.config.AbstractRegistryConfiguration;
import net.sourceforge.nattable.config.IConfigRegistry;
import net.sourceforge.nattable.data.convert.DefaultIntegerDisplayConverter;
import net.sourceforge.nattable.edit.EditConfigAttributes;
import net.sourceforge.nattable.edit.editor.ComboBoxCellEditor;
import net.sourceforge.nattable.edit.editor.ICellEditor;
import net.sourceforge.nattable.filterrow.FilterRowDataLayer;
import net.sourceforge.nattable.filterrow.TextMatchingMode;
import net.sourceforge.nattable.filterrow.config.FilterRowConfigAttributes;
import net.sourceforge.nattable.style.DisplayMode;

import com.beone.java.nattable.data.DataModelConstants;
import com.beone.java.nattable.data.Person.Gender;

/**
 * The configuration to enable the edit mode for the grid and additional
 * edit configurations like converters and validators.
 * 
 * @author Dirk Fauth
 */
public class FilterRowConfiguration extends AbstractRegistryConfiguration {

	@Override
	public void configureRegistry(IConfigRegistry configRegistry) {

		//register a combo box cell editor for the gender column in the filter row
		//the label is set automatically to the value of 
		//FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + column position
		ICellEditor comboBoxCellEditor = new ComboBoxCellEditor(Arrays.asList(Gender.FEMALE, Gender.MALE));
		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITOR, 
				comboBoxCellEditor, 
				DisplayMode.NORMAL, 
				FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + DataModelConstants.GENDER_COLUMN_POSITION);

		
		//register a combo box cell editor for the married column in the filter row
		//the label is set automatically to the value of 
		//FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + column position
		comboBoxCellEditor = new ComboBoxCellEditor(Arrays.asList(Boolean.TRUE, Boolean.FALSE));
		configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITOR, 
				comboBoxCellEditor, 
				DisplayMode.NORMAL, 
				FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + DataModelConstants.MARRIED_COLUMN_POSITION);
		

		configRegistry.registerConfigAttribute(
				FilterRowConfigAttributes.FILTER_DISPLAY_CONVERTER, 
				new DefaultIntegerDisplayConverter(), 
				DisplayMode.NORMAL, 
				FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + DataModelConstants.HOUSENUMBER_COLUMN_POSITION);
		
		
		configRegistry.registerConfigAttribute(TEXT_MATCHING_MODE, 
				TextMatchingMode.EXACT, 
				DisplayMode.NORMAL, 
				FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + DataModelConstants.GENDER_COLUMN_POSITION);

		configRegistry.registerConfigAttribute(TEXT_MATCHING_MODE, 
				TextMatchingMode.REGULAR_EXPRESSION, 
				DisplayMode.NORMAL, 
				FilterRowDataLayer.FILTER_ROW_COLUMN_LABEL_PREFIX + DataModelConstants.HOUSENUMBER_COLUMN_POSITION);
	
		configRegistry.registerConfigAttribute(FilterRowConfigAttributes.TEXT_DELIMITER, "&");

	}

}
