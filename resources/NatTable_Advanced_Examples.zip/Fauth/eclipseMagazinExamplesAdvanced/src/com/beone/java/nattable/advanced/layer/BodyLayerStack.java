package com.beone.java.nattable.advanced.layer;

import net.sourceforge.nattable.copy.command.CopyDataCommandHandler;
import net.sourceforge.nattable.group.ColumnGroupExpandCollapseLayer;
import net.sourceforge.nattable.group.ColumnGroupModel;
import net.sourceforge.nattable.group.ColumnGroupReorderLayer;
import net.sourceforge.nattable.group.RowGroupExpandCollapseLayer;
import net.sourceforge.nattable.group.model.RowGroupModel;
import net.sourceforge.nattable.hideshow.ColumnHideShowLayer;
import net.sourceforge.nattable.hideshow.RowHideShowLayer;
import net.sourceforge.nattable.layer.AbstractLayerTransform;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.IUniqueIndexLayer;
import net.sourceforge.nattable.layer.stack.DefaultBodyLayerStack;
import net.sourceforge.nattable.reorder.ColumnReorderLayer;
import net.sourceforge.nattable.selection.SelectionLayer;
import net.sourceforge.nattable.selection.config.DefaultSelectionLayerConfiguration;
import net.sourceforge.nattable.tree.ITreeRowModel;
import net.sourceforge.nattable.tree.TreeLayer;
import net.sourceforge.nattable.viewport.ViewportLayer;

import com.beone.java.nattable.advanced.configuration.SelectionStyleConfiguration;

/**
 * The BodyLayerStack consists of the following layers:<br/>
 * <ol>
 * <li>{@link ColumnReorderLayer}</li>
 * <li>{@link ColumnGroupReorderLayer} - only if column grouping is enabled</li>
 * <li>{@link ColumnHideShowLayer}</li>
 * <li>{@link ColumnGroupExpandCollapseLayer} - only if column grouping is enabled</li>
 * <li>{@link SelectionLayer}</li>
 * <li>{@link ViewportLayer}</li>
 * </ol>

 * They are build uppon a layer which has to be given as parameter when
 * creating the {@link BodyLayerStack}. Normally this should be a {@link DataLayer}
 * that contains the data to be shown.
 * <p>The {@link BodyLayerStack} has a similar structure to the {@link DefaultBodyLayerStack}, by
 * adding support functionality for column grouping. It is possible to build this body layer stack
 * without column grouping functionality by don't using a {@link ColumnGroupModel} object on 
 * instantiating it. This way the {@link BodyLayerStack} will be the same as the {@link DefaultBodyLayerStack}
 * despite a different styling of the {@link SelectionLayer}.
 * 
 * @author Dirk Fauth
 */
public class BodyLayerStack extends AbstractLayerTransform {

	/**
	 * Layer that adds the functionality of column reordering.
	 */
	private final ColumnReorderLayer columnReorderLayer;
	
	/**
	 * Layer that adds the functionality of column group reordering.
	 */
	private final ColumnGroupReorderLayer columnGroupReorderLayer;
	
	/**
	 * Layer that adds the functionality of hiding/showing columns.
	 */
	private final ColumnHideShowLayer columnHideShowLayer;
	
	/**
	 * Layer that adds the functionality of tracking the expand/collapse state of
	 * a column group.
	 */
	private final ColumnGroupExpandCollapseLayer columnGroupExpandCollapseLayer;
	
	/**
	 * Layer that enables selection
	 */
	private final SelectionLayer selectionLayer;
	
	/**
	 * Layer that handles the visible part of the NatTable.
	 * This one makes the NatTable VIRTUAL.
	 */
	private final ViewportLayer viewportLayer;

	/**
	 * Creates a new {@link BodyLayerStack} on top of the given layer.
	 * Will create a body layer stack without special support for column grouping functionality.
	 * @param underlyingLayer The layer on which this body layer should be build.
	 * 			Normally the underlying layer is a {@link DataLayer}.
	 */
	public BodyLayerStack(IUniqueIndexLayer underlyingLayer) {
		this(underlyingLayer, null, null, null);
	}
	
	/**
	 * Creates a new {@link BodyLayerStack} on top of the given layer.
	 * @param underlyingLayer The layer on which this body layer should be build.
	 * 			Normally the underlying layer is a {@link DataLayer}.
	 * @param columnGroupModel The ColumnGroupModel which is used to configure the 
	 * 			column groups. Has to be the same as for the column header so header and
	 * 			body use the same column group configuration.
	 * 			Can be <code>null</code> which indicates that the body layer stack does not
	 * 			add special column grouping functionality.
	 */
	public BodyLayerStack(IUniqueIndexLayer underlyingLayer, ColumnGroupModel columnGroupModel) {
		this(underlyingLayer, columnGroupModel, null, null);
	}
	
	/**
	 * Creates a new {@link BodyLayerStack} on top of the given layer.
	 * @param underlyingLayer The layer on which this body layer should be build.
	 * 			Normally the underlying layer is a {@link DataLayer}.
	 * @param rowGroupModel The RowGroupModel which is used to configure the row groups. 
	 * 			Can be <code>null</code> which indicates that the body layer stack does not
	 * 			add special row grouping functionality.
	 */
	@SuppressWarnings("rawtypes")
	public BodyLayerStack(IUniqueIndexLayer underlyingLayer, RowGroupModel rowGroupModel) {
		this(underlyingLayer, null, rowGroupModel, null);
	}
	
	/**
	 * Creates a new {@link BodyLayerStack} on top of the given layer.
	 * @param underlyingLayer The layer on which this body layer should be build.
	 * 			Normally the underlying layer is a {@link DataLayer}.
	 * @param treeRowModel The ITreeRowModel which is used to configure the tree. 
	 * 			Can be <code>null</code> which indicates that the body layer stack does not
	 * 			add special tree functionality.
	 */
	@SuppressWarnings("rawtypes")
	public BodyLayerStack(IUniqueIndexLayer underlyingLayer, ITreeRowModel treeRowModel) {
		this(underlyingLayer, null, null, treeRowModel);
	}

	/**
	 * Creates a new {@link BodyLayerStack} on top of the given layer.
	 * @param underlyingLayer The layer on which this body layer should be build.
	 * 			Normally the underlying layer is a {@link DataLayer}.
	 * @param columnGroupModel The ColumnGroupModel which is used to configure the 
	 * 			column groups. Has to be the same as for the column header so header and
	 * 			body use the same column group configuration.
	 * 			Can be <code>null</code> which indicates that the body layer stack does not
	 * 			add special column grouping functionality.
	 * @param rowGroupModel The RowGroupModel which is used to configure the row groups. 
	 * 			Can be <code>null</code> which indicates that the body layer stack does not
	 * 			add special row grouping functionality.
	 * @param treeRowModel The ITreeRowModel which is used to configure the tree. 
	 * 			Can be <code>null</code> which indicates that the body layer stack does not
	 * 			add special tree functionality.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public BodyLayerStack(IUniqueIndexLayer underlyingLayer, ColumnGroupModel columnGroupModel, 
			RowGroupModel rowGroupModel, ITreeRowModel treeRowModel) {
		columnReorderLayer = new ColumnReorderLayer(underlyingLayer);
		
		IUniqueIndexLayer layer = null;
		
		//only enable column group layers if the body layer stack is given a ColumnGroupModel
		if (columnGroupModel != null) {
			columnGroupReorderLayer = new ColumnGroupReorderLayer(columnReorderLayer, columnGroupModel);
			columnHideShowLayer = new ColumnHideShowLayer(columnGroupReorderLayer);
			columnGroupExpandCollapseLayer = new ColumnGroupExpandCollapseLayer(columnHideShowLayer, columnGroupModel);
			layer = columnGroupExpandCollapseLayer;
		} else {
			//if no ColumnGroupModel is given we create a body layer stack that is despite of styling
			//configuration of the SelectionLayer the same as the DefaultBodyLayerStack
			columnGroupReorderLayer = null;
			columnGroupExpandCollapseLayer = null;
			columnHideShowLayer = new ColumnHideShowLayer(columnReorderLayer);
			layer = columnHideShowLayer;
		}

		if (rowGroupModel != null) {
			//if there is a RowGroupModel, the body layer stack will get the RowHideShowLayer
			//and the RowGroupExpandCollapseLayer to enable row grouping
			RowHideShowLayer rowHideShowLayer = new RowHideShowLayer(layer);		
			layer = new RowGroupExpandCollapseLayer(rowHideShowLayer, rowGroupModel);
		}
		
		//creation of the SelectionLayer without default configuration
		selectionLayer = new SelectionLayer(layer, false);
		//adding customized configuration
		selectionLayer.addConfiguration(new DefaultSelectionLayerConfiguration() {

			@Override
			protected void addSelectionStyleConfig() {
				addConfiguration(new SelectionStyleConfiguration());
			}

		});
		
		if (treeRowModel != null) {
			TreeLayer treeLayer = new TreeLayer(selectionLayer, treeRowModel, true);
			viewportLayer = new ViewportLayer(treeLayer);
		}
		else {
			viewportLayer = new ViewportLayer(selectionLayer);
		}
		
		//as this layer stack is a layer itself, we have to set the ViewportLayer
		//as underlying layer to match the NatTable architecture
		setUnderlyingLayer(viewportLayer);

		//add the command handler to support copying selected data into the clipboard
		//the action that triggers the execution of this command handler is configured
		//within the DefaultSelectionBindings of the SelectionLayer
		registerCommandHandler(new CopyDataCommandHandler(selectionLayer));
	}

	/**
	 * @return The {@link ColumnReorderLayer} of this body layer stack
	 */
	public ColumnReorderLayer getColumnReorderLayer() {
		return columnReorderLayer;
	}

	/**
	 * @return The {@link ColumnGroupReorderLayer} of this body layer stack
	 */
	public ColumnGroupReorderLayer getColumnGroupReorderLayer() {
		return columnGroupReorderLayer;
	}

	/**
	 * @return The {@link ColumnHideShowLayer} of this body layer stack
	 */
	public ColumnHideShowLayer getColumnHideShowLayer() {
		return columnHideShowLayer;
	}

	/**
	 * @return The {@link ColumnGroupExpandCollapseLayer} of this body layer stack
	 */
	public ColumnGroupExpandCollapseLayer getColumnGroupExpandCollapseLayer() {
		return columnGroupExpandCollapseLayer;
	}

	/**
	 * @return The {@link SelectionLayer} of this body layer stack
	 */
	public SelectionLayer getSelectionLayer() {
		return selectionLayer;
	}

	/**
	 * @return The {@link ViewportLayer} of this body layer stack
	 */
	public ViewportLayer getViewportLayer() {
		return viewportLayer;
	}
}
