package com.beone.java.nattable.advanced.configuration;

import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.layer.LabelStack;
import net.sourceforge.nattable.layer.cell.AbstractOverrider;
import net.sourceforge.nattable.layer.cell.ColumnOverrideLabelAccumulator;
import net.sourceforge.nattable.layer.cell.RowOverrideLabelAccumulator;

import com.beone.java.nattable.data.DataModelConstants;
import com.beone.java.nattable.data.Person;
import com.beone.java.nattable.data.PersonWithAddress;

/**
 * This class is used to dynamically attach labels dependent on the values within
 * the data provider and on specific columns.
 * You could also use a {@link ColumnOverrideLabelAccumulator} for the column based
 * labels and a {@link RowOverrideLabelAccumulator} for the row based label.
 * 
 * @author Dirk Fauth
 */
public class CellLabelOverrider extends AbstractOverrider {

	public static final String FEMALE_LABEL = "femaleLabel";
	public static final String GENDER_LABEL = "genderLabel";
	public static final String MARRIED_LABEL = "marriedLabel";
	public static final String BIRTHDAY_LABEL = "birthdayLabel";
	public static final String HOUSENUMBER_LABEL = "housenumberLabel";
	public static final String POSTALCODE_LABEL = "postalCodeLabel";
	
	private IDataProvider dataProvider;
	
	public CellLabelOverrider(IDataProvider dataProvider) {
		this.dataProvider = dataProvider;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void accumulateConfigLabels(LabelStack configLabels, int columnPosition, int rowPosition) {
		if (dataProvider instanceof IRowDataProvider<?>) {
			Object rowObject = ((IRowDataProvider<PersonWithAddress>)dataProvider).getRowObject(rowPosition);
			// Added a check for the data type of the row object because of tree and group by feature
			// because there are rows for grouping of the tree within the NatTable which are not of the type
			// the value objects are and therefore could lead to ClassCastExceptions if not checked
			if (rowObject instanceof Person) {
				if (((Person)rowObject).getGender().equals(Person.Gender.FEMALE)) {
					configLabels.addLabel(FEMALE_LABEL);
				}
				
				switch (columnPosition) {
				case (DataModelConstants.GENDER_COLUMN_POSITION):
					configLabels.addLabel(GENDER_LABEL);
				break;
				case (DataModelConstants.MARRIED_COLUMN_POSITION):
					configLabels.addLabel(MARRIED_LABEL);
				break;
				case (DataModelConstants.BIRTHDAY_COLUMN_POSITION):
					configLabels.addLabel(BIRTHDAY_LABEL);
				break;
				case (DataModelConstants.HOUSENUMBER_COLUMN_POSITION):
					configLabels.addLabel(HOUSENUMBER_LABEL);
				break;
				case (DataModelConstants.POSTALCODE_COLUMN_POSITION):
					configLabels.addLabel(POSTALCODE_LABEL);
				break;
				}
			}
		}
	}

}
