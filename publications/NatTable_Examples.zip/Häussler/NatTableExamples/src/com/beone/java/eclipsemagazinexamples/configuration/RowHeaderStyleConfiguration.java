package com.beone.java.eclipsemagazinexamples.configuration;

import net.sourceforge.nattable.layer.config.DefaultRowHeaderStyleConfiguration;
import net.sourceforge.nattable.painter.cell.TextPainter;
import net.sourceforge.nattable.style.HorizontalAlignmentEnum;
import net.sourceforge.nattable.style.VerticalAlignmentEnum;
import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.FontData;

/**
 * Simple style configuration for the row header of a grid.
 * Extends {@link DefaultRowHeaderStyleConfiguration} so we only have to adjust the
 * style properties instead of creating a completely new configuration.
 * @author Dirk H�u�ler
 */
public class RowHeaderStyleConfiguration extends DefaultRowHeaderStyleConfiguration {

	{
		this.font = GUIHelper.getFont(new FontData("Arial", 8, SWT.ITALIC));
		this.bgColor = GUIHelper.COLOR_WIDGET_BACKGROUND;
		this.fgColor = GUIHelper.COLOR_WIDGET_FOREGROUND;
		this.hAlign = HorizontalAlignmentEnum.CENTER;
		this.vAlign = VerticalAlignmentEnum.MIDDLE;
		this.borderStyle = null;

		this.cellPainter = new TextPainter();
	}

}
