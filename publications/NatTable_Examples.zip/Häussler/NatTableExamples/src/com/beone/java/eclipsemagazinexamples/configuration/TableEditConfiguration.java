package com.beone.java.eclipsemagazinexamples.configuration;

import java.text.SimpleDateFormat;
import java.util.Arrays;

import net.sourceforge.nattable.config.AbstractRegistryConfiguration;
import net.sourceforge.nattable.config.CellConfigAttributes;
import net.sourceforge.nattable.config.IConfigRegistry;
import net.sourceforge.nattable.config.IEditableRule;
import net.sourceforge.nattable.data.convert.DefaultBooleanDisplayConverter;
import net.sourceforge.nattable.data.convert.DefaultIntegerDisplayConverter;
import net.sourceforge.nattable.data.validate.DefaultNumericDataValidator;
import net.sourceforge.nattable.data.validate.IDataValidator;
import net.sourceforge.nattable.edit.EditConfigAttributes;
import net.sourceforge.nattable.edit.editor.CheckBoxCellEditor;
import net.sourceforge.nattable.edit.editor.ComboBoxCellEditor;
import net.sourceforge.nattable.edit.editor.ICellEditor;
import net.sourceforge.nattable.style.DisplayMode;

import com.beone.java.eclipsemagazinexamples.data.DataModelConstants;
import com.beone.java.eclipsemagazinexamples.data.DateDisplayConverter;
import com.beone.java.eclipsemagazinexamples.data.Person.Gender;

/**
 * The configuration to enable the edit mode for the grid and additional
 * edit configurations like converters and validators.
 * @author Dirk H�u�ler
 */
public class TableEditConfiguration extends AbstractRegistryConfiguration {

	@Override
	public void configureRegistry(IConfigRegistry configRegistry) {
		//register the IEditableRule to set all columns of the NatTable to be always
		//editable.
		configRegistry.registerConfigAttribute(
				EditConfigAttributes.CELL_EDITABLE_RULE, 
				IEditableRule.ALWAYS_EDITABLE, 
				DisplayMode.EDIT);

		//register a combo box cell editor for the gender column
		//the label has to be set within an AbstractOverrider (in this example within
		//CellLabelOverrider)
		ICellEditor comboBoxCellEditor = new ComboBoxCellEditor(Arrays.asList(Gender.FEMALE, Gender.MALE));
		configRegistry.registerConfigAttribute(
				EditConfigAttributes.CELL_EDITOR, comboBoxCellEditor, 
				DisplayMode.EDIT, CellLabelOverrider.GENDER_LABEL);

		//register a checkbox cell editor for the married column
		//the label has to be set within an AbstractOverrider (in this example within
		//CellLabelOverrider)
		configRegistry.registerConfigAttribute(
				EditConfigAttributes.CELL_EDITOR, new CheckBoxCellEditor(), 
				DisplayMode.EDIT, CellLabelOverrider.MARRIED_LABEL);
		
		//register display converter for Boolean, Integer and Date
		configRegistry.registerConfigAttribute(
				CellConfigAttributes.DISPLAY_CONVERTER, 
				new DefaultBooleanDisplayConverter(), 
				DisplayMode.NORMAL, 
				CellLabelOverrider.MARRIED_LABEL);

		configRegistry.registerConfigAttribute(
				CellConfigAttributes.DISPLAY_CONVERTER, 
				new DateDisplayConverter(DataModelConstants.DATE_FORMAT_PATTERN), 
				DisplayMode.NORMAL, 
				CellLabelOverrider.BIRTHDAY_LABEL);

		configRegistry.registerConfigAttribute(
				CellConfigAttributes.DISPLAY_CONVERTER, 
				new DefaultIntegerDisplayConverter(), 
				DisplayMode.NORMAL, 
				CellLabelOverrider.HOUSENUMBER_LABEL);

		configRegistry.registerConfigAttribute(
				CellConfigAttributes.DISPLAY_CONVERTER, 
				new DefaultIntegerDisplayConverter(), 
				DisplayMode.NORMAL, 
				CellLabelOverrider.POSTALCODE_LABEL);
		
		//register validator for date and postal code
		configRegistry.registerConfigAttribute(
				EditConfigAttributes.DATA_VALIDATOR, 
				getDateValidator(), 
				DisplayMode.EDIT, 
				CellLabelOverrider.BIRTHDAY_LABEL);

		configRegistry.registerConfigAttribute(
				EditConfigAttributes.DATA_VALIDATOR, 
				new DefaultNumericDataValidator(), 
				DisplayMode.EDIT, 
				CellLabelOverrider.HOUSENUMBER_LABEL);

		configRegistry.registerConfigAttribute(
				EditConfigAttributes.DATA_VALIDATOR, 
				getPostalCodeValidator(), 
				DisplayMode.EDIT, 
				CellLabelOverrider.POSTALCODE_LABEL);
	}

	/**
	 * Returns a validator that checks if the entered value is a correct date value.
	 * Mainly this is the same as the date converter, but for the current NatTable
	 * implementation, this is needed to work correctly.
	 */
	private static IDataValidator getDateValidator() {
		return new IDataValidator(){

			public boolean validate(int columnIndex, int rowIndex, Object newValue) {
				if (newValue == null){
					return false;
				}
				SimpleDateFormat sdf = new SimpleDateFormat(DataModelConstants.DATE_FORMAT_PATTERN);
				try {
					sdf.parse((String)newValue);
				}
				catch (Exception e) {
					return false;
				}
				return true;
			}
		};
	}

	/**
	 * Returns a validator that checks if the value has 5 digits.
	 */
	private static IDataValidator getPostalCodeValidator() {
		return new IDataValidator(){

			public boolean validate(int columnIndex, int rowIndex, Object newValue) {
				if (newValue == null){
					return false;
				}

				if (newValue instanceof Integer) {
					String postalCodeAsString = newValue.toString();
					if (postalCodeAsString.length() != 5) {
						return false;
					}
				}
				else {
					return false;
				}
				return true;
			}
		};
	}

}
