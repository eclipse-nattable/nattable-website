package com.beone.java.nattable.advanced.layer;

import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.columnChooser.command.DisplayColumnChooserCommandHandler;
import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.grid.data.DefaultColumnHeaderDataProvider;
import net.sourceforge.nattable.grid.layer.ColumnHeaderLayer;
import net.sourceforge.nattable.group.ColumnGroupHeaderLayer;
import net.sourceforge.nattable.group.ColumnGroupModel;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.ILayer;
import net.sourceforge.nattable.layer.config.DefaultColumnHeaderLayerConfiguration;

import com.beone.java.nattable.advanced.configuration.CellLabelOverrider;
import com.beone.java.nattable.advanced.configuration.ColumnHeaderStyleConfiguration;
import com.beone.java.nattable.data.PersonWithAddress;

/**
 * Subclass of {@link BaseGridLayer} which adds the column grouping
 * functionality.
 * 
 * @author Dirk Fauth
 * 
 */
public class ColumnGroupingGridLayer extends BaseGridLayer {

	protected ColumnGroupHeaderLayer columnGroupHeaderLayer;

	protected ColumnGroupModel columnGroupModel;

	public ColumnGroupingGridLayer(List<PersonWithAddress> values,
			String[] propertyNames, Map<String, String> propertyToLabelMap,
			ConfigRegistry configRegistry) {
		super(values, propertyNames, propertyToLabelMap, configRegistry);
	}

	@Override
	protected BodyLayerStack createBodyLayerStack(List<PersonWithAddress> values) {
		IDataProvider bodyDataProvider = new ListDataProvider<PersonWithAddress>(
				values, columnPropertyAccessor);
		bodyDataLayer = new DataLayer(bodyDataProvider);

		bodyDataLayer.setConfigLabelAccumulator(new CellLabelOverrider(
				bodyDataProvider));

		BodyLayerStack bodyLayer = new BodyLayerStack(bodyDataLayer,
				getColumnGroupModel());
		selectionLayer = bodyLayer.getSelectionLayer();
		return bodyLayer;
	}

	@Override
	protected ILayer createColumnHeaderLayer(BodyLayerStack bodyLayer,
			ConfigRegistry configRegistry) {
		// create the data layer
		columnHeaderDataLayer = new DataLayer(
				new DefaultColumnHeaderDataProvider(propertyNames,
						propertyToLabelMap), 100, 20);
		// create a default column header layer for the given data layer and the
		// dependency on the body layer
		// and don't use the default configuration
		ColumnHeaderLayer columnHeaderLayer = new ColumnHeaderLayer(
				columnHeaderDataLayer, bodyLayer, selectionLayer, false);
		// add your special configuration for customizing
		columnHeaderLayer
				.addConfiguration(new DefaultColumnHeaderLayerConfiguration() {

					@Override
					protected void addColumnHeaderStyleConfig() {
						addConfiguration(new ColumnHeaderStyleConfiguration());
					}

				});

		columnGroupHeaderLayer = new ColumnGroupHeaderLayer(columnHeaderLayer,
				selectionLayer, getColumnGroupModel());

		// add column chooser to column header
		DisplayColumnChooserCommandHandler columnChooserCommandHandler = new DisplayColumnChooserCommandHandler(
				selectionLayer, bodyLayer.getColumnHideShowLayer(),
				columnHeaderLayer, columnHeaderDataLayer,
				columnGroupHeaderLayer, getColumnGroupModel());
		columnHeaderLayer.registerCommandHandler(columnChooserCommandHandler);

		return columnGroupHeaderLayer;
	}

	public ColumnGroupHeaderLayer getColumnGroupHeaderLayer() {
		return this.columnGroupHeaderLayer;
	}

	protected ColumnGroupModel getColumnGroupModel() {
		if (this.columnGroupModel == null) {
			this.columnGroupModel = new ColumnGroupModel();
		}
		return this.columnGroupModel;
	}
}
