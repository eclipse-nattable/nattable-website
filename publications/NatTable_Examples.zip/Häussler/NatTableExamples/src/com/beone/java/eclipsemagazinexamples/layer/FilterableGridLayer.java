package com.beone.java.eclipsemagazinexamples.layer;

import java.util.List;

import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.extension.glazedlists.GlazedListsEventLayer;
import net.sourceforge.nattable.extension.glazedlists.filterrow.DefaultGlazedListsFilterStrategy;
import net.sourceforge.nattable.filterrow.FilterRowHeaderComposite;
import net.sourceforge.nattable.grid.layer.DefaultGridLayer;
import net.sourceforge.nattable.grid.layer.GridLayer;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.ILayer;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.FilterList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.SortedList;
import ca.odell.glazedlists.TransformedList;
import ca.odell.glazedlists.matchers.CompositeMatcherEditor;

import com.beone.java.eclipsemagazinexamples.configuration.CellLabelOverrider;
import com.beone.java.eclipsemagazinexamples.data.PersonWithAddress;
import com.beone.java.eclipsemagazinexamples.data.PersonWithAddressColumnPropertyAccessor;

/**
 * Subclass of {@link SortableGridLayer} which overrides the creation of the column header
 * and body layer stacks and the body data provider to enable filtering with GlazedLists by
 * adding a filter row to the column header.
 * @author Dirk H�u�ler
 */
public class FilterableGridLayer extends SortableGridLayer {

	/**
	 * Reference to the GlazedLists which wraps the original data list.
	 */
	protected FilterList<PersonWithAddress> filterList;
	
	/**
	 * Creates a {@link GridLayer} that has all functionality a {@link DefaultGridLayer} has,
	 * adding custom data access, styling, sorting and filtering to the NatTable.
	 * @param values the list of the objects to show within the NatTable
	 * @param configRegistry the config registry, needed for additional functionality configuration,
	 * e.g. sorting
	 */
	public FilterableGridLayer(List<PersonWithAddress> values, ConfigRegistry configRegistry) {
		super(values, configRegistry);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected ListDataProvider<PersonWithAddress> createBodyDataProvider(List<PersonWithAddress> values) {
		//wrapping of the list to show into GlazedLists
		//see http://publicobject.com/glazedlists/ for further information
		EventList<PersonWithAddress> eventList = GlazedLists.eventList(values);
		TransformedList<PersonWithAddress, PersonWithAddress> rowObjectsGlazedList = GlazedLists.threadSafeList(eventList);
		
		//use the SortedList constructor with 'null' for the Comparator because the Comparator
		//will be set by configuration
		sortedList = new SortedList<PersonWithAddress>(rowObjectsGlazedList, null);
		// wrap the SortedList with the FilterList
		filterList = new FilterList<PersonWithAddress>(sortedList);
		columnPropertyAccessor = new PersonWithAddressColumnPropertyAccessor();
		return new ListDataProvider<PersonWithAddress>(filterList, columnPropertyAccessor);
	}
	
	/**
	 * {@inheritDoc}
	 * The only change to {@link SortableGridLayer#createBodyLayerStack(ListDataProvider)} is that
	 * the {@link GlazedListsEventLayer} ist created with the filterList and not the sortedList.
	 */
	@Override
	protected StyledBodyLayerStack createBodyLayerStack(ListDataProvider<PersonWithAddress> bodyDataProvider) {
		bodyDataLayer = new DataLayer(bodyDataProvider);
		bodyDataLayer.setConfigLabelAccumulator(new CellLabelOverrider(bodyDataProvider));
		
		//layer for event handling of GlazedLists and PropertyChanges
		GlazedListsEventLayer<PersonWithAddress> glazedListsEventLayer = 
			new GlazedListsEventLayer<PersonWithAddress>(bodyDataLayer, filterList);

		StyledBodyLayerStack bodyLayerStack = new StyledBodyLayerStack(glazedListsEventLayer);
		selectionLayer = bodyLayerStack.getSelectionLayer();
		return bodyLayerStack;
	}
	
	/**
	 * {@inheritDoc}
	 * It also adds the {@link FilterRowHeaderComposite} to enable the filter row.
	 */
	@Override
	protected ILayer createColumnHeaderLayer(
			IDataProvider columnHeaderDataProvider, 
			ILayer bodyLayer,
			ConfigRegistry configRegistry) {
		
		ILayer columnHeaderLayer = super.createColumnHeaderLayer(
				columnHeaderDataProvider, bodyLayer, configRegistry);
		
		//	Note: The column header layer is wrapped in a filter row composite.
		//	This plugs in the filter row functionality
		CompositeMatcherEditor<PersonWithAddress> autoFilterMatcherEditor = new CompositeMatcherEditor<PersonWithAddress>();
		filterList.setMatcherEditor(autoFilterMatcherEditor);
		
		FilterRowHeaderComposite<PersonWithAddress> filterRowHeaderLayer =
			new FilterRowHeaderComposite<PersonWithAddress>(
					new DefaultGlazedListsFilterStrategy<PersonWithAddress>(autoFilterMatcherEditor, columnPropertyAccessor, configRegistry),
					columnHeaderLayer, columnHeaderDataProvider, configRegistry
			);
		
		return filterRowHeaderLayer;
	}
}
