package com.beone.java.nattable.advanced.layer;

import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.config.CellConfigAttributes;
import net.sourceforge.nattable.config.ConfigRegistry;
import net.sourceforge.nattable.config.IConfigRegistry;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.grid.GridRegion;
import net.sourceforge.nattable.group.RowGroupHeaderLayer;
import net.sourceforge.nattable.group.RowGroupHeaderTextPainter;
import net.sourceforge.nattable.group.config.DefaultRowGroupHeaderLayerConfiguration;
import net.sourceforge.nattable.group.model.RowGroup;
import net.sourceforge.nattable.group.model.RowGroupModel;
import net.sourceforge.nattable.layer.DataLayer;
import net.sourceforge.nattable.layer.ILayer;
import net.sourceforge.nattable.painter.cell.VerticalTextPainter;
import net.sourceforge.nattable.painter.cell.decorator.BeveledBorderDecorator;
import net.sourceforge.nattable.style.DisplayMode;

import com.beone.java.nattable.advanced.configuration.CellLabelOverrider;
import com.beone.java.nattable.data.PersonWithAddress;

/**
 * Subclass of {@link ColumnGroupingGridLayer} that adds row grouping
 * functionality.
 * 
 * @author Dirk Fauth
 * 
 */
public class RowGroupingGridLayer extends ColumnGroupingGridLayer {

	private RowGroupModel<PersonWithAddress> rowGroupModel;

	public RowGroupingGridLayer(List<PersonWithAddress> values,
			String[] propertyNames, Map<String, String> propertyToLabelMap,
			ConfigRegistry configRegistry) {
		super(values, propertyNames, propertyToLabelMap, configRegistry);
	}

	@Override
	protected BodyLayerStack createBodyLayerStack(List<PersonWithAddress> values) {
		IRowDataProvider<PersonWithAddress> bodyDataProvider = new ListDataProvider<PersonWithAddress>(
				values, columnPropertyAccessor);
		bodyDataLayer = new DataLayer(bodyDataProvider);

		bodyDataLayer.setConfigLabelAccumulator(new CellLabelOverrider(
				bodyDataProvider));

		// create row group model
		rowGroupModel = new RowGroupModel<PersonWithAddress>();
		rowGroupModel.setDataProvider(bodyDataProvider);

		// Create a group of rows for the model.
		RowGroup<PersonWithAddress> rowGroup = new RowGroup<PersonWithAddress>(
				rowGroupModel, "Group 1");
		rowGroup.addMemberRow(bodyDataProvider.getRowObject(0));
		rowGroup.addMemberRow(bodyDataProvider.getRowObject(1));
		rowGroup.addStaticMemberRow(bodyDataProvider.getRowObject(2));
		rowGroupModel.addRowGroup(rowGroup);

		rowGroup = new RowGroup<PersonWithAddress>(rowGroupModel, "Group 2");
		rowGroup.addMemberRow(bodyDataProvider.getRowObject(3));
		rowGroup.addMemberRow(bodyDataProvider.getRowObject(4));
		rowGroup.addStaticMemberRow(bodyDataProvider.getRowObject(5));
		rowGroupModel.addRowGroup(rowGroup);

		rowGroup = new RowGroup<PersonWithAddress>(rowGroupModel, "Group 3",
				true);
		rowGroup.addMemberRow(bodyDataProvider.getRowObject(6));
		rowGroup.addMemberRow(bodyDataProvider.getRowObject(7));
		rowGroup.addMemberRow(bodyDataProvider.getRowObject(8));
		rowGroup.addStaticMemberRow(bodyDataProvider.getRowObject(9));
		rowGroupModel.addRowGroup(rowGroup);

		BodyLayerStack bodyLayer = new BodyLayerStack(bodyDataLayer,
				getColumnGroupModel(), rowGroupModel, null);
		selectionLayer = bodyLayer.getSelectionLayer();
		return bodyLayer;
	}

	@Override
	protected ILayer createRowHeaderLayer(ILayer bodyLayer) {
		ILayer rhl = super.createRowHeaderLayer(bodyLayer);
		RowGroupHeaderLayer<PersonWithAddress> rowGroupHeaderLayer = new RowGroupHeaderLayer<PersonWithAddress>(
				rhl, selectionLayer, rowGroupModel, false);

		// configure VerticalTextPainter so row group names are printed
		// vertically
		rowGroupHeaderLayer
				.addConfiguration(new DefaultRowGroupHeaderLayerConfiguration<PersonWithAddress>(
						rowGroupModel) {
					@Override
					public void configureRegistry(IConfigRegistry configRegistry) {
						configRegistry
								.registerConfigAttribute(
										CellConfigAttributes.CELL_PAINTER,
										new BeveledBorderDecorator(
												new RowGroupHeaderTextPainter<PersonWithAddress>(
														rowGroupModel,
														new VerticalTextPainter())),
										DisplayMode.NORMAL,
										GridRegion.ROW_GROUP_HEADER);
					}
				});

		rowGroupHeaderLayer.setColumnWidth(20);
		return rowGroupHeaderLayer;
	}
}
