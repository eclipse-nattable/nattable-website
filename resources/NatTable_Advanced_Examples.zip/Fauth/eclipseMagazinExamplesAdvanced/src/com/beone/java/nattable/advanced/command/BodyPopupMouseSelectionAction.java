package com.beone.java.nattable.advanced.command;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.ui.menu.IMenuItemProvider;
import net.sourceforge.nattable.ui.menu.PopupMenuBuilder;
import net.sourceforge.nattable.viewport.ViewportLayer;
import net.sourceforge.nattable.viewport.command.ViewportSelectRowCommand;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;

/**
 * Action class that should be registered on right click on the body layer.
 * Predicts that row selection is enabled. 
 * First it checks whether the row the selection occured is already selected.
 * If not the row will be selected. After that a context menu will be shown
 * with the option to delete the selected item.
 * 
 * @author Dirk Fauth
 *
 */
public class BodyPopupMouseSelectionAction extends SimpleMouseSelectionAction {

	public BodyPopupMouseSelectionAction(ViewportLayer viewPortLayer) {
		super(viewPortLayer);
	}

    @Override
	public void run(NatTable natTable, MouseEvent event) {
    	super.run(natTable, event);
    	
    	//if the row the click occured is not yet selected, select it now
		if (!isSingleRowFullySelected(natTable)) {
	    	//select the row
			natTable.doCommand(new ViewportSelectRowCommand(
					natTable, 
					getGridRowPosition(), 
					isWithShiftMask(), 
					isWithControlMask()));
		}
		
		//open the menu
		int[] selRows = viewPortLayer.getSelectionLayer().getFullySelectedRowPositions();
		Menu menu = new PopupMenuBuilder(natTable)
			.withMenuItemProvider(deleteRowMenuItemProvider(selRows)).build();

		menu.setData(event.data);
		menu.setVisible(true);
    }
    
    /**
     * Creates a context menu with the delete entry.
     * @param rowIndexes
     * @return
     */
	public static IMenuItemProvider deleteRowMenuItemProvider(final int[] rowIndexes) {
		return new IMenuItemProvider() {

			public void addMenuItem(final NatTable natTable, final Menu popupMenu) {
				MenuItem menuItem = new MenuItem(popupMenu, SWT.PUSH);
				menuItem.setText("Delete");
				menuItem.setEnabled(true);

				menuItem.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent event) {
						natTable.doCommand(new DeleteRowCommand(rowIndexes));
					}
				});
			}
		};
	}

}
